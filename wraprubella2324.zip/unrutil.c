                        /* unrutil.c */
						
/* The functions in this file have been extracted from Press WH, Teukolsky SA, Vetterling WT and Flannery BR. 
Numerical recipes in C: the art of scientific computing. 2nd ed. Cambridge University
Press; Cambridge 1992.						*/
						
# include <stdio.h>
# include <stddef.h>
# include <stdlib.h>
# define NR_END 1
# define FREE_ARG char*

void nrerror(char error_text[]){
               /*Numerical Recipes standard error handler */
  fprintf(stderr,"Numerical Recipes run-time error...\n");
  fprintf(stderr,"%s\n",error_text);
  fprintf(stderr,"...now exiting to system...\n");
  exit(1);
}

float *vector(int nl, int nh){
             /*Allocate a float vector with subscript range v[nl..nh]*/
  float *v;

  v=(float *)malloc((size_t) ((nh-nl+1+NR_END)*sizeof(float)));
  if (!v) nrerror("allocation failure in vector()");
  return v-nl+NR_END;
}

double *dvector(int nl, int nh){
             /*Allocate a double vector with subscript range v[nl..nh] */
  double *v;

  v=(double *)malloc((size_t) ((nh-nl+1+NR_END)*sizeof(double)));
  if (!v) nrerror("allocation failure in dvector()");
  return v-nl+NR_END;
}
  
int *ivector(int nl,int nh)
            /*allocate an int vector with subscript range v[nl..nh] */
{
  int *v;

  v=(int *)malloc((size_t) ((nh-nl+1+NR_END)*sizeof(int)));
  if(!v) nrerror("allocation failure in ivector()");
  return v-nl+NR_END;
}

int *iivector(int nl,int nh)
            /*allocate an int vector with subscript range v[nl..nh] */
{
  int **v;

  *v=(int *)malloc((size_t) ((nh-nl+1+NR_END)*sizeof(int)));
  if(!(*v)) nrerror("allocation failure in iivector()");
  return (*v)-nl+NR_END;
}



unsigned long *ulvector(int nl,int nh)
            /*allocate an unsigned long vector with subscript range v[nl..nh] */
{
  unsigned long *v;

  v=(unsigned long *)malloc((size_t) ((nh-nl+1+NR_END)*sizeof(unsigned long)));
  if(!v) nrerror("allocation failure in ulvector()");
  return v-nl+NR_END;
}

float **matrix(int nrl, int nrh, int ncl, int nch)
            /* allocate a float matrix with subscript range m[nrl..nrh][ncl..nc] */
{
     int i, nrow=nrh-nrl+1,ncol=nch-ncl+1;
     float **m;

     /* allocate pointers to rows */

     m=(float **) malloc((size_t)((nrow+NR_END)*sizeof(float*)));
     if (!m) nrerror("allocation failure 1 in matrix()");
     m += NR_END;
     m -= nrl;
     
       /* Allocate rows and set pointers to them */

     m[nrl]=(float *) malloc((size_t)((nrow*ncol+NR_END)*sizeof(float)));
     m[nrl] += NR_END;
     m[nrl] -= ncl;

     for (i=nrl+1;i<=nrh;i++) m[i]=m[i-1]+ncol;
     /* return pointer to array of pointers to rows */
     return m;
}


int **imatrix(int nrl, int nrh, int ncl, int nch)
            /* allocate an int matrix with subscript range m[nrl..nrh][ncl..nc] */
{
     int i, nrow=nrh-nrl+1,ncol=nch-ncl+1;
     int **m;

     /* allocate pointers to rows */

     m=(int **) malloc((size_t)((nrow+NR_END)*sizeof(int*)));
     if (!m) nrerror("allocation failure 1 in imatrix()");
     m += NR_END;
     m -= nrl;
     
       /* Allocate rows and set pointers to them */

     m[nrl]=(int *) malloc((size_t)((nrow*ncol+NR_END)*sizeof(int)));
     m[nrl] += NR_END;
     m[nrl] -= ncl;

     for (i=nrl+1;i<=nrh;i++) m[i]=m[i-1]+ncol;
     /* return pointer to array of pointers to rows */
     return m;
}


double **dmatrix(int nrl, int nrh, int ncl, int nch)
            /* allocate a double matrix with subscript range m[nrl..nrh][ncl..nc] */
{
     int i, nrow=nrh-nrl+1,ncol=nch-ncl+1;
     double **m;

     /* allocate pointers to rows */

     m=(double **) malloc((size_t)((nrow+NR_END)*sizeof(double*)));
     if (!m) nrerror("allocation failure 1 in dmatrix()");
     m += NR_END;
     m -= nrl;
     
       /* Allocate rows and set pointers to them */

     m[nrl]=(double *) malloc((size_t)((nrow*ncol+NR_END)*sizeof(double)));
     m[nrl] += NR_END;
     m[nrl] -= ncl;

     for (i=nrl+1;i<=nrh;i++) m[i]=m[i-1]+ncol;
     /* return pointer to array of pointers to rows */
     return m;
}

int ***i3tensor(int nrl, int nrh, int ncl, int nch, int ndl, int ndh)
/* allocate an int 3tensor with range t[nrl..nrh][ncl..nch][ndl..ndh]] */
{
  int i,j,nrow=nrh-nrl+1, ncol=nch-ncl+1, ndep=ndh-ndl+1;
  int ***t;

  /* allocate pointers to pointers to rows */
  t=(int ***) malloc((size_t)((nrow+NR_END)*sizeof(int**)));
  if (!t) nrerror("allocation failure 1 in i3tensor()");
  t += NR_END;
  t -= nrl;

  /* allocate pointers to rows and set pointers to them */
  t[nrl] = (int **) malloc((size_t)((nrow*ncol+NR_END)*sizeof(int*)));
  if (!t[nrl]) nrerror("allocation failure 2 in i3tensor()");  
  t[nrl] += NR_END;
  t[nrl] -= ncl;

  /* allocate rows and set pointers to them */
  t[nrl][ncl] = (int *) malloc((size_t)((nrow*ncol*ndep+NR_END)*sizeof(int)));
  if (!t[nrl][ncl]) nrerror("allocation failure 3 in i3tensor()");  
  t[nrl][ncl] += NR_END;
  t[nrl][ncl] -= ndl;
  
  for (j=ncl+1;j<=nch;j++) t[nrl][j]=t[nrl][j-1]+ndep;
  for (i=nrl+1;i<=nrh;i++){
  	t[i]=t[i-1]+ncol;
  	t[i][ncl]=t[i-1][ncl]+ncol*ndep;
  	for (j=ncl+1;j<=nch;j++) t[i][j]=t[i][j-1] + ndep;
  }
  /* return pointer to array of pointers to rows */
  return t;
}  



float ***f3tensor(int nrl, int nrh, int ncl, int nch, int ndl, int ndh)
/* allocate a float 3tensor with range t[nrl..nrh][ncl..nch][ndl..ndh]] */
{
  int i,j,nrow=nrh-nrl+1, ncol=nch-ncl+1, ndep=ndh-ndl+1;
  float ***t;

  /* allocate pointers to pointers to rows */
  t=(float ***) malloc((size_t)((nrow+NR_END)*sizeof(float**)));
  if (!t) nrerror("allocation failure 1 in f3tensor()");
  t += NR_END;
  t -= nrl;

  /* allocate pointers to rows and set pointers to them */
  t[nrl] = (float **) malloc((size_t)((nrow*ncol+NR_END)*sizeof(float*)));
  if (!t[nrl]) nrerror("allocation failure 2 in f3tensor()");  
  t[nrl] += NR_END;
  t[nrl] -= ncl;

  /* allocate rows and set pointers to them */
  t[nrl][ncl] = (float *) malloc((size_t)((nrow*ncol*ndep+NR_END)*sizeof(float)));
  if (!t[nrl][ncl]) nrerror("allocation failure 3 in f3tensor()");  
  t[nrl][ncl] += NR_END;
  t[nrl][ncl] -= ndl;
  
  for (j=ncl+1;j<=nch;j++) t[nrl][j]=t[nrl][j-1]+ndep;
  for (i=nrl+1;i<=nrh;i++){
  	t[i]=t[i-1]+ncol;
  	t[i][ncl]=t[i-1][ncl]+ncol*ndep;
  	for (j=ncl+1;j<=nch;j++) t[i][j]=t[i][j-1] + ndep;
  }
  /* return pointer to array of pointers to rows */
  return t;
}  



double ***d3tensor(int nrl, int nrh, int ncl, int nch, int ndl, int ndh)
/* allocate a double d3tensor with range t[nrl..nrh][ncl..nch][ndl..ndh]] */
{
  int i,j,nrow=nrh-nrl+1, ncol=nch-ncl+1, ndep=ndh-ndl+1;
  double ***t;

  /* allocate pointers to pointers to rows */
  t=(double ***) malloc((size_t)((nrow+NR_END)*sizeof(double**)));
  if (!t) nrerror("allocation failure 1 in d3tensor()");
  t += NR_END;
  t -= nrl;

  /* allocate pointers to rows and set pointers to them */
  t[nrl] = (double **) malloc((size_t)((nrow*ncol+NR_END)*sizeof(double*)));
  if (!t[nrl]) nrerror("allocation failure 2 in d3tensor()");  
  t[nrl] += NR_END;
  t[nrl] -= ncl;

  /* allocate rows and set pointers to them */
  t[nrl][ncl] = (double *) malloc((size_t)((nrow*ncol*ndep+NR_END)*sizeof(double)));
  if (!t[nrl][ncl]) nrerror("allocation failure 3 in d3tensor()");  
  t[nrl][ncl] += NR_END;
  t[nrl][ncl] -= ndl;
  
  for (j=ncl+1;j<=nch;j++) t[nrl][j]=t[nrl][j-1]+ndep;
  for (i=nrl+1;i<=nrh;i++){
  	t[i]=t[i-1]+ncol;
  	t[i][ncl]=t[i-1][ncl]+ncol*ndep;
  	for (j=ncl+1;j<=nch;j++) t[i][j]=t[i][j-1] + ndep;
  }
  /* return pointer to array of pointers to rows */
  return t;
}  


  
void free_vector(float *v, int nl,int nh)
    /* free a float vector allocated with vector() */
{
  free((FREE_ARG) (v+nl-NR_END));
}


void free_dvector(double *v, int nl,int nh)
    /* free a double vector allocated with vector() */
{
  free((FREE_ARG) (v+nl-NR_END));
} 


     
void free_ivector(int *v, int nl,int nh)
    /* free an int vector allocated with ivector()  */
{
  free((FREE_ARG) (v+nl-NR_END));
}

void free_ulvector(unsigned long *v, int nl,int nh)
    /* free an unsigned long vector allocated with ivector()  */
{
  free((FREE_ARG) (v+nl-NR_END));
} 

void free_matrix(float **m, int nrl, int nrh, int ncl, int nch)
            /* free a float matrix allocated by matrix() */
{
  free((FREE_ARG) (m[nrl]+ncl-NR_END));
  free((FREE_ARG) (m+nrl-NR_END));
} 

void free_imatrix(int **m, int nrl, int nrh, int ncl, int nch)
            /* free an int matrix allocated by imatrix() */
{
  free((FREE_ARG) (m[nrl]+ncl-NR_END));
  free((FREE_ARG) (m+nrl-NR_END));
} 


void free_dmatrix(double **m, int nrl, int nrh, int ncl, int nch)
            /* free a double matrix allocated by matrix() */
{
  free((FREE_ARG) (m[nrl]+ncl-NR_END));
  free((FREE_ARG) (m+nrl-NR_END));
} 


void free_i3tensor(int ***t, int nrl, int nrh, int ncl, int nch,
              int ndl, int ndh)
            /* free an int i3tensor allocated by i3tensor() */
{
  free((FREE_ARG) (t[nrl][ncl]+ndl-NR_END));
  free((FREE_ARG) (t[nrl]+ncl-NR_END));  
  free((FREE_ARG) (t+nrl-NR_END));
}



void free_f3tensor(float ***t, int nrl, int nrh, int ncl, int nch,
              int ndl, int ndh)
            /* free a float f3tensor allocated by f3tensor() */
{
  free((FREE_ARG) (t[nrl][ncl]+ndl-NR_END));
  free((FREE_ARG) (t[nrl]+ncl-NR_END));  
  free((FREE_ARG) (t+nrl-NR_END));
}

void free_d3tensor(double ***t, int nrl, int nrh, int ncl, int nch,
              int ndl, int ndh)
            /* free a double d3tensor allocated by d3tensor() */
{
  free((FREE_ARG) (t[nrl][ncl]+ndl-NR_END));
  free((FREE_ARG) (t[nrl]+ncl-NR_END));  
  free((FREE_ARG) (t+nrl-NR_END));
} 

double ****d4tensor(int nrl, int nrh, int ncl, int nch, int ndl, int ndh, int nal, int nah)
/* APC allocate an int 3tensor with range t[nrl..nrh][ncl..nch][ndl..ndh]] */
{
  int r,c,d,nrow=nrh-nrl+1, ncol=nch-ncl+1, ndep=ndh-ndl+1, ndim_a=nah-nal+1;
  double ****t;

  /* allocate pointers to pointers to rows */
  t=(double ****) malloc((size_t)((nrow+NR_END)*sizeof(double***)));
  if (!t) nrerror("allocation failure 1 in d4tensor()");
  t += NR_END;
  t -= nrl;


  /* allocate pointers to rows and set pointers to them */
  t[nrl] = (double ***) malloc((size_t)((nrow*ncol+NR_END)*sizeof(double**)));
  if (!t[nrl]) nrerror("allocation failure 2 in d4tensor()");
  t[nrl] += NR_END;
  t[nrl] -= ncl;



     /* allocate pointers to rows and set pointers to them */
 t[nrl][ncl] = (double **) malloc((size_t)((nrow*ncol*ndep+NR_END)*sizeof(double*)));
 if (!t[nrl][ncl]) nrerror("allocation failure 3 in d4tensor()");
 t[nrl][ncl] += NR_END;
 t[nrl][ncl] -= ndl;


 /* allocate rows and set pointers to them */
 t[nrl][ncl][ndl] = (double *) malloc((size_t)((nrow*ncol*ndep*ndim_a+NR_END)*sizeof(double)));
 if (!t[nrl][ncl][ndl]) nrerror("allocation failure 4 in d4tensor()");
 t[nrl][ncl][ndl] += NR_END;
 t[nrl][ncl][ndl] -= nal;
    for(r=nrl;r<=nrh;r++)
	{
		if (r > nrl)
		{
			t[r] = t[r-1] + ncol ;
		    t[r][ncl]=t[r-1][ncl]+ncol*ndep;
		    t[r][ncl][ndl] = t[r-1][ncl][ndl] + ncol*ndep*ndim_a ;
		}
		for(c=ncl;c<=nch;c++)
		{
			if (c > ncl)
			{
				t[r][c]=t[r][c-1] + ndep ;
				t[r][c][ndl] = t[r][c-1][ndl] + ndep*ndim_a ;
			}

			for(d=ndl;d<=ndh;d++)
			{
				if (d > ndl) t[r][c][d] = t[r][c][d-1] + ndim_a ;
			}
		}
	}


	/* return pointer to pointer to array of pointers to rows */
  return t;
}


void free_d4tensor(double ****t, int nrl, int nrh, int ncl, int nch, int ndl, int ndh, int nal, int nah)
            /* APC free an int i3tensor allocated by i3tensor() */
{
  free((FREE_ARG) (t[nrl][ncl][ndl]+nal-NR_END));
  free((FREE_ARG) (t[nrl][ncl]+ndl-NR_END));
  free((FREE_ARG) (t[nrl]+ncl-NR_END));
  free((FREE_ARG) (t+nrl-NR_END));
}

