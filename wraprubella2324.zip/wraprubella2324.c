/*   Wrapping code for program which can be used to run the rubella model used for VIMC runs, 2023-4
     Author of the wrapping code - Emilia Vynnycky 
	 
	 The wrapping code relies on code in the following files:
	wrap_rubella2324.c
	 unrutil.c

*/

# include <stdio.h>
# include <stdlib.h>
# include <string.h>

# define vln_lngth 5000
# define strngln 50
# define ln_lngth 400
# define line_lngth 500

double *dvector(int nl, int nh);
void free_dvector(double *v, int nl,int nh);


void get_vcov_files(int scenario_num,char vcov_summary[],char sia_covfile[],
                    char rcv1_covfile[],
                    char rcv2_covfile[]);
					
void get_demogfiles(int num_demog_files,char demog_summary[],char brate_file[],
              char male_surv_file[],char fem_surv_file[],
			  char male_popfile[],char fem_popfile[],
			  char lexpectancy_file[],
			  char agespec_fert_file[]);					

int main(int argc, char *argv[]) {

int start_country_num,fin_country_num,cnum,fin_year;
int num_demog_files;
int first_rep,final_rep;
float pvacc_again_RCV1RCV2,frac_import;
int scenario_num;

char command[50],bsfile[strngln],crsmortfile[strngln];
char crsriskfile[strngln],sffile[strngln],vefile[strngln];
char bssumfile[strngln],vcov_summary[strngln],demog_summary[strngln];
char sia_covfile[strngln],rcv1_covfile[strngln],rcv2_covfile[strngln];
char brate_file[strngln],male_surv_file[strngln],fem_surv_file[strngln];
char male_popfile[strngln],fem_popfile[strngln];
char lexpectancy_file[strngln],agespec_fert_file[strngln];

char callprog[ln_lngth];

//  The following checks to see whether the correct number of inputs have been supplied on the command line and sends an error message if it's incorrect
if ( argc != 9){  
   fprintf(stderr,"\n\nUnfortunately, you have supplied wrong command line arguments :(. \nYou need to supply 8 on the same line that you call this program...\n");
   fprintf(stderr,"These are: start_country_num\n fin_country_num\n first_rep\n");
   fprintf(stderr,"final_rep\nscenario_num\n");
   fprintf(stderr,"bssummary_file\nvaccine_coverage_summary_file\n");
   fprintf(stderr,"demog_summary_file\n");
   exit(-1);
}

// The following assigns each of the arguments in the command line to inputs which will be used for the model runs
start_country_num = atoi(argv[1]);       // Number of the first country to be used in the runs
fin_country_num = atoi(argv[2]);         // Number of the last country to be used in the runs
first_rep = atoi(argv[3]);               // Number of the first repetition (parameter combination) to be used in the runs
final_rep = atoi(argv[4]);               // Number of the last repetition (parameter combination) to be used in the runs
scenario_num = atoi(argv[5]);            // Number of the vaccine scenario  to be used in the runs

strcpy(bssumfile,argv[6]);               // Name of the file containing the names of files specifying the bootstrao-derived force of infection, country code and DALYs for each country
strcpy(vcov_summary,argv[7]);            // Name of the file containing the names of the SIA, RCV1 and RCV2 vaccination coverage files for each scenario 

strcpy(demog_summary,argv[8]);            // Name of file containing the names of the demography files 

num_demog_files=7;                        // Number of demography files

pvacc_again_RCV1RCV2=1.0;                 // Proportion of RCV2 recipients who have had RCV1
frac_import=0.0;                          // Importation fraction (not used)

fin_year=2101;                            // Final year for the model runs.

get_vcov_files(scenario_num,vcov_summary,sia_covfile,rcv1_covfile,rcv2_covfile);   // This reads in the names of the vaccination coverage files provided by VIMC for the given scenario


printf("bssumfile=%s vcov_summary=%s demog_summary=%s\n",bssumfile,vcov_summary,demog_summary);
printf("sia_covfile=%s rcv1_covfile=%s rcv2_covfile=%s\n",
                sia_covfile,rcv1_covfile,rcv2_covfile);

get_demogfiles(num_demog_files,demog_summary,brate_file,male_surv_file,fem_surv_file,
			  male_popfile,fem_popfile,
			  lexpectancy_file,
			  agespec_fert_file);                    // This reads in the names of the demography files provided by VIMC

printf("num_demog_files=%d brate_file=%s male_surv_file=%s fem_surv_file=%s\n",
      num_demog_files,brate_file,
	  male_surv_file,fem_surv_file);

printf("male_popfile=%s fem_popfile=%s lexpectancy_file=%s agespec_fert_file=%s\n",
			  male_popfile,fem_popfile,
			  lexpectancy_file,
			  agespec_fert_file);
 
 
// The following loops over each of the countries specified on the command line and calls up the rubella model with the command line that it needs to run.
 
for (cnum=start_country_num;cnum<=fin_country_num;++cnum){       

	  printf("cnum=%d fin_year=%d scenario_num=%d first_rep=%d final_rep=%d\n",
	           cnum,fin_year,scenario_num,first_rep,final_rep);
	  printf("sia_covfile=%s rcv1_covfile=%s rcv2_covfile=%s bssumfile=%s\n",
        	  sia_covfile,rcv1_covfile,rcv2_covfile,bssumfile);
      printf("pvacc_again_RCV1RCV2=%4.4f frac_import=%4.4f\n",
			  pvacc_again_RCV1RCV2,frac_import);
	  printf("brate_file=%s male_surv_file=%s fem_surv_file=%s male_popfile=%s fem_popfile=%s lexpectancy_file=%s agespec_fert_file=%s\n",
			  brate_file,
			  male_surv_file,
			  fem_surv_file,
			  male_popfile,
			  fem_popfile,
			  lexpectancy_file,
			  agespec_fert_file);

	  sprintf(callprog,"%s %d %d %d %d %d %s %s %s %s %4.4f %4.4f %s %s %s %s %s %s %s > test%d.out",
        	  "main_rubella2324",
			  cnum,
			  fin_year,
			  scenario_num,
			  first_rep,
			  final_rep,			  
			  sia_covfile,
			  rcv1_covfile,
			  rcv2_covfile,
			  bssumfile,
			  pvacc_again_RCV1RCV2,
			  frac_import,
			  brate_file,
			  male_surv_file,
			  fem_surv_file,
			  male_popfile,
			  fem_popfile,
			  lexpectancy_file,
			  agespec_fert_file,
			  cnum);   //check re cnum here

	  fprintf(stderr,"callcprog=%s\n",callprog);
			  			 		  
//	  printf("rep=%d callprog=%s\n",rep,callprog);
	  system(callprog);
}
   return(0);
   
} 



void get_vcov_files(int scenario_num,char vcov_summary[],char sia_covfile[],
                    char rcv1_covfile[],
                    char rcv2_covfile[]){
 // This reads in the names of the vaccination coverage files provided by VIMC for the given scenario						
						
int scennum;
int found_scen;
char dummy[strngln];
char scov[strngln],rcv1cov[strngln],rcv2cov[strngln];
char *p,cur_lin[line_lngth],summary_file[strngln];
FILE *ifp;

strcpy(summary_file,"inputfiles/\0");
strcat(summary_file,vcov_summary);
printf("summary_file=%s \n",summary_file);

if ( (ifp=fopen(summary_file,"r")) == NULL) {
      printf("\nCannot open summary_file %s- bye!",summary_file);
      exit(1);   
}
p=fgets(cur_lin,line_lngth,ifp);
// printf("cur_lin[0]=%c\n",cur_lin[0]);
while (cur_lin[0]=='*')  {
    p=fgets(cur_lin,line_lngth,ifp);
    printf("cur_lin[0]=%c\n",cur_lin[0]);
}
found_scen=0;

while  ((cur_lin[0] != '!' ) && (found_scen==0))  { 	   
   sscanf(p, "%s%d%s%s%s", dummy,&scennum,scov,rcv1cov,rcv2cov);  
  if (scennum==scenario_num) {   
      sprintf(sia_covfile,"%s",scov,"\0");
	  sprintf(rcv1_covfile,"%s",rcv1cov,"\0");	  
	  sprintf(rcv2_covfile,"%s",rcv2cov,"\0");
	  found_scen=1;
   }
 	p=fgets(cur_lin,line_lngth,ifp);
}
if (found_scen==0){
  fprintf(stderr,"Details for the scenario that you are looking for (scenario_num=%d) haven't been found...\n",scenario_num);
  fprintf(stderr,"Please check the summary file and the value for the scenario\nExiting program...\n");
  exit(1);
}
  printf("at end of function scenario_num=%d  sia_covfile=%s rcv1_covfile=%s rcv2_covfile=%s\\n",
                 scenario_num,sia_covfile,rcv1_covfile,rcv2_covfile);
  fclose(ifp);
}



void get_demogfiles(int num_demog_files,char demog_summary[],char brate_file[],
              char male_surv_file[],char fem_surv_file[],
			  char male_popfile[],char fem_popfile[],
			  char lexpectancy_file[],
			  char agespec_fert_file[]){
    // This reads in the names of the demography files provided by VIMC
				  
				  
int found_num,file_num;
char dummy[strngln],filename[strngln];
char *p,cur_lin[line_lngth],summary_file[strngln];
FILE *ifp;

strcpy(summary_file,"inputfiles/\0");
strcat(summary_file,demog_summary);
printf("summary_file=%s \n",summary_file);

if ( (ifp=fopen(summary_file,"r")) == NULL) {
      printf("\nCannot open summary_file %s- bye!",summary_file);
      exit(1);   
}
p=fgets(cur_lin,line_lngth,ifp);
// printf("cur_lin[0]=%c\n",cur_lin[0]);
while (cur_lin[0]=='*')  {
    p=fgets(cur_lin,line_lngth,ifp);
    printf("cur_lin[0]=%c\n",cur_lin[0]);
}
found_num=0;

while  ((cur_lin[0] != '!' ) && (found_num< num_demog_files))  { 	   
   sscanf(p, "%d%s%s", &file_num,dummy,filename);    
  if (file_num==1)  sprintf(brate_file,"%s",filename,"\0");
  if (file_num==2)  sprintf(male_surv_file,"%s",filename,"\0");  
  if (file_num==3)  sprintf(fem_surv_file,"%s",filename,"\0");  
  if (file_num==4)  sprintf(male_popfile,"%s",filename,"\0");  
  if (file_num==5)  sprintf(fem_popfile,"%s",filename,"\0");  
  if (file_num==6)  sprintf(lexpectancy_file,"%s",filename,"\0");  
  if (file_num==7)  sprintf(agespec_fert_file,"%s",filename,"\0");  
  found_num=file_num;
  p=fgets(cur_lin,line_lngth,ifp);
}
if (found_num<num_demog_files){
  fprintf(stderr,"Error in reading in the names of the demography files\n");
  fprintf(stderr,"Please check the summary file\n");
  exit(1);
}
  fclose(ifp);
}

