# include <stdio.h>
# include <math.h>
# include <stdlib.h>
# include <time.h>
# include <string.h>


# define strngln 50
# define strgln_long 200
# define bsline_lngth 1500
# define vfile_lngth 65
# define ln_lngth 1500
# define vln_lngth 5000
# define dum_dpts 12
# define line_lngth 500
# define min(x,y) (((x)<(y))?(x):(y))
# define max(x,y) (((x)>(y))?(x):(y))

double **dmatrix(int nrl, int nrh, int ncl, int nch);
double *dvector(int nl, int nh);
float **matrix(int nrl, int nrh, int ncl, int nch);
double ***d3tensor(int nrl, int nrh, int ncl, int nch, int ndl, int ndh);
void free_vector(float *v, int nl,int nh);
void free_dvector(double *v, int nl,int nh);
void free_dmatrix(double **m, int nrl, int nrh, int ncl, int nch);
void free_d3tensor(double ***t, int nrl, int nrh, int ncl, int nch,
              int ndl, int ndh);


void get_bscountrycode_abbrev2017(int country_num,int *country_code,char selcntry[],char country_abbrev[], 
                                     double *daly_factor,char bs_sourcefile[],
                                     char bs_sourcename[], char bs_avefile[]){
/* Finds the UN 
   country_code for the given country by reading in its value from bs_sourcefile that's specified in the command line. 
   For these runs, we used bsdalcc2024.inp.  Whilst it's in this function, it also reads in the name of the files holding 
   the force of infection for the country, as well as the daly */


int cnum,cc,sel_cntrynum;
int found_cntry;
double dfact;
char cntry[strngln], cntry_abb[strngln],bs_name[strngln], bsa[ strngln ];
char *p,cur_lin[line_lngth],summary_file[strngln];
FILE *ifp;

strcpy(summary_file,"inputfiles/\0");

strcat(summary_file,bs_sourcefile);

printf("summary_file=%s \n",summary_file);

if ( (ifp=fopen(summary_file,"r")) == NULL) {
      printf("\nCannot open summary_file %s- bye!",summary_file);
      exit(1);   
}
p=fgets(cur_lin,line_lngth,ifp);
// printf("cur_lin[0]=%c\n",cur_lin[0]);
while (cur_lin[0]=='*')  {
    p=fgets(cur_lin,line_lngth,ifp);

     printf("cur_lin[0]=%c\n",cur_lin[0]);
}
found_cntry=0;

while  ((cur_lin[0] != 'Z' ) && (found_cntry==0))  { 	   
   sscanf(p, "%d%s%s%d%lf%s%s", &cnum, cntry, cntry_abb, &cc, &dfact,bs_name, bsa);  
  // printf("in get_country_code etc sel_cntrynum=%d cnum=%d cc=%d\n",sel_cntrynum,cnum,cc); // cnum=%d cc=%s \n",cnum,cc);
  if (cnum==country_num) {   

      sprintf(selcntry,"%s",cntry,"\0");
	  sprintf(country_abbrev,"%s",cntry_abb,"\0");	  
	  sprintf(bs_sourcename,"%s",bs_name,"\0");

      *country_code=cc;
	  *daly_factor=dfact;

	  sprintf( bs_avefile, "%s", bsa, "\0");
	  found_cntry=1;
   }
   	p=fgets(cur_lin,line_lngth,ifp);
}
if (found_cntry==0){
  fprintf(stderr,"Details for the country that you are looking for (country_num=%d) haven't been found...\n",country_num);
  fprintf(stderr,"Please check the summary file and the value for country_num\nExiting program...\n");
  exit(1);
}
  printf("at end of function cnum=%d country_name=%s country_abbrev=%s *country_code=%d bs_sourcename=%s *bs_avefile=%s\n",
                 cnum,selcntry,country_abbrev,*country_code,bs_sourcename,bs_avefile);
  fclose(ifp);
  }

void get_implife_expectancy(char life_expectancy_file[],
                 double life_expectancy_at_birth[],
                 int country_code,int min_year,int max_year){
/* This function reads in the life expectancy from the file provided by VIMC */				 
					 
				 
int cc,low_age,high_age; 
int done_country,age,yy,year;
double lexpectancy;
char abbrev[strngln],gend[strngln],*p,cur_lin[vln_lngth];
FILE *ifp;  
  
  if ( (ifp=fopen(life_expectancy_file,"r")) == NULL) {
    printf("\nCannot open life expectancy file %s - bye!",life_expectancy_file);
    exit(1);
 }
 p=fgets(cur_lin,vln_lngth,ifp);
 printf("in get_implife_expectancy min_year=%d max_year=%d \n",
                   min_year,max_year);


 printf("cur_lin[0]=%c\n",cur_lin[0]);
 while (cur_lin[0]=='*')  {
    p=fgets(cur_lin,vln_lngth,ifp); printf("*");fputs(p,stdout);
    printf("cur_lin[0]=%c\n",cur_lin[0]);
 }
 done_country=0;
 while ((cur_lin[0] != '!' ) && (done_country==0) ){  // Note end of file denoted by ! not by Z, as names of some countries starts with Z
   sscanf(p,"%d%s%d%d%d%s%lf",&cc,abbrev,&low_age,&high_age,&yy,gend,&lexpectancy);  
/*    printf("cc=%d abbrev=%s low_age=%d high_age=%d yy=%d gend=%s popgrp=%10.6e \n",
                   cc,abbrev,low_age,high_age,yy,gend,popgrp); */
 //  popwidth=high_age-low_age+1; 
 //  exit(1);
    if ( (low_age>0) || (high_age>0) ) {
	  printf("!!! Error incorrect low_age or high_age in input file for life expectancy..\n");
	  printf("!!Expecting 0 for low_age and high_age in input file for life expectancy..\n");
	  printf("low_age=%d high_age=%d\nexiting program",low_age,high_age);	  
	  exit(1);
	}
	if ((cc==country_code) && (yy>=min_year) && (yy<=max_year) && (done_country==0)  ){
         life_expectancy_at_birth[yy]=lexpectancy;
	   if (yy==max_year) done_country=1;
	}	 
	// printf("done_country=%d\n",done_country);
    p=fgets(cur_lin,vln_lngth,ifp);
 }
 fclose(ifp);

}




void get_imppopdata(char popfile[],double **obs_pop,int country_code,int min_year,int max_year,
                 int min_age,int maxage){
/* This function reads in the age and sex specific population size from the files provided by VIMC */					 
					 
int cc,low_age,high_age; 
int done_country,age,yy,year,popwidth;
double popgrp;
char abbrev[strngln],gend[strngln],*p,cur_lin[vln_lngth];
FILE *ifp;  
  
  if ( (ifp=fopen(popfile,"r")) == NULL) {
    printf("\nCannot open population file %s - bye!",popfile);
    exit(1);
 }
 p=fgets(cur_lin,vln_lngth,ifp);
 printf("in get_imppopdata min_year=%d max_year=%d min_age=%d maxage=%d\n",min_year,max_year,min_age,maxage);

// exit(1);
 
 printf("cur_lin[0]=%c\n",cur_lin[0]);
 while (cur_lin[0]=='*')  {
    p=fgets(cur_lin,vln_lngth,ifp); printf("*");fputs(p,stdout);
    printf("cur_lin[0]=%c\n",cur_lin[0]);
 }
 done_country=0;
 while ((cur_lin[0] != '!' ) && (done_country==0) ){  // Note end of file denoted by ! not by Z, as names of some countries starts with Z
   sscanf(p,"%d%s%d%d%d%s%lf",&cc,abbrev,&low_age,&high_age,&yy,gend,&popgrp);  
/*    printf("cc=%d abbrev=%s low_age=%d high_age=%d yy=%d gend=%s popgrp=%10.6e \n",
                   cc,abbrev,low_age,high_age,yy,gend,popgrp); */
   popwidth=high_age-low_age+1; 

	if ((cc==country_code) && (yy>=min_year) && (yy<=max_year) && (done_country==0)  ){
	   for (age=low_age;age<=min(high_age,maxage);++age)
         obs_pop[yy][age]=popgrp/(1.0*popwidth);
	   if ((yy==max_year) && (age>maxage) ) done_country=1;
	}	 

    p=fgets(cur_lin,vln_lngth,ifp);
 }
 fclose(ifp);

}

void get_imp_brate_2017(char brate_file[],int country_code,float ann_brate[],
                         int start_sim,int fin_year,int reqd_brate_year){
/* This function reads in the birth rate for 
the year specified by reqd_brate_year from the file provided by VIMC */


int cc,found_cntry,year,yy,low_age,high_age;
double abr;
char abbrev[strngln],gend[strngln], *p,cur_lin[line_lngth]; 
FILE *ifp;
  
  
if ( (ifp=fopen(brate_file,"r")) == NULL) {
      printf("\nCannot open brate_file %s- bye!",brate_file);
      exit(1);   
}
p=fgets(cur_lin,line_lngth,ifp);
// printf("cur_lin[0]=%c\n",cur_lin[0]);
while (cur_lin[0]=='*')  {
    p=fgets(cur_lin,line_lngth,ifp);

     printf("cur_lin[0]=%c\n",cur_lin[0]);
}
found_cntry=0;

while  ((cur_lin[0] != '!' ) && (found_cntry==0))  { 	   
   sscanf(p,"%d%s%d%d%d%s%lf",&cc,abbrev,&low_age,&high_age,&yy,gend,&abr);  
/*   printf("cc=%d abbrev=%s low_age=%d high_age=%d yy=%d gend=%s abr=%10.6e \n",
                   cc,abbrev,low_age,high_age,yy,gend,abr); */
   if ((cc==country_code) && (yy==reqd_brate_year) ) {
	  found_cntry=1;
	  for (year=start_sim;year<=fin_year;++year) ann_brate[year]=abr;
   }
   	p=fgets(cur_lin,line_lngth,ifp);
}
if (found_cntry==0){
  fprintf(stderr,"Details for the country that you are looking for (country_code=%d) haven't been found...\n",country_code);
  fprintf(stderr,"Please check the birth rate file and the value for country_code\nExiting program...\n");
  exit(1);
}
  printf("at end of function country_code=%d abr=%10.6e ann_brate[year=%d]=%10.6e\n",
                 country_code,abr,1950,ann_brate[1950]);
  fclose(ifp);
  }


double convert_to_daily(double para){

double tsteps_pyr,daily_para;

tsteps_pyr=365.0;

daily_para=1-pow((1-para),1/tsteps_pyr);

return daily_para;
}

double convert_para(double para,int tstep){
double tsteps_pyr,daily_para;
double converted_para;

converted_para=1-pow((1-para),1/(tstep*1.0));

return converted_para;
}


void get_imp_mrate(char alivefile[],double m_rate[],int country_code,int min_age,int maxage,int reqd_demog_year){
/* This function calculates the mortality rate from the survival files provided by VIMC */	
	
int i,loc,gps_in_file,gend_num;
int done_country,age,yy,year;
int l_age,low_age,up_age,high_age,gp,last_low_age_in_file;
int tsteps_pyr;
double alive0,alive4,*alive5,alivex,alive85t99,alive100t120;
double mort0,mort4,mort5,mort80t84,mort85t99,mort95t99;
double daily_mort4,daily_mort5,daily_mort80t84,daily_mort85t99,daily_mort95t99;

char abbrev[strngln],gend[strngln],*p,cur_lin[vln_lngth];
FILE *ifp;  
  
  if ( (ifp=fopen(alivefile,"r")) == NULL) {
    printf("\nCannot open alive file %s - bye!",alivefile);
    exit(1);
 }
 p=fgets(cur_lin,vln_lngth,ifp);

 gps_in_file=20;   
 last_low_age_in_file = 100;
 tsteps_pyr=365;
 alive5=dvector(1,gps_in_file);
 printf("cur_lin[0]=%c\n",cur_lin[0]);
 while (cur_lin[0]=='*')  {
    p=fgets(cur_lin,vln_lngth,ifp);fputs(p,stdout);
    printf("cur_lin[0]=%c\n",cur_lin[0]);
 }
 done_country=0;
 while ((cur_lin[0] != '!' ) && (done_country==0) ){
    sscanf(p,"%d%s%d%d%d%s%lf",
    	&loc,abbrev,&low_age,&high_age,&yy,gend,&alivex);
/*    printf("loc=%d abbrev=%s low_age=%d  high_age=%d yy=%d  gend=%s alivex=%10.6e\n",
	          loc,abbrev,low_age,high_age,yy,gend,alivex);*/
//	exit(1);
    if (low_age==0) alive0=alivex;
	if (low_age==1) alive4=alivex;
	if ((low_age>=5) && (low_age<100)) {
		gp=low_age/5;
		alive5[gp]=alivex;
	//	printf("gp=%d low_age=%d alive5=%10.6e\n",gp,low_age,alive5[gp]);
	}
	if ((low_age==100) && (high_age==120)){		 
	  alive100t120=alivex;
	//  printf("alive100t120=%10.6e\n",alive100t120);
    }
	if ((loc==country_code) &&(done_country==0) && (yy==reqd_demog_year) && (low_age==last_low_age_in_file)) {
	   mort0=(alive0-alive4)/alive0;
	   m_rate[0]=convert_to_daily(mort0);
	   
	   mort4=(alive4-alive5[1])/alive4;
	 //  printf("mort4=%10.6e tsteps_pyr=%d\n",mort4,tsteps_pyr);
	   daily_mort4=convert_para(mort4,4*tsteps_pyr);
//	   printf("daily_mort4=%10.6e",daily_mort4);
	   
	   for (age=1;age<=4;++age) m_rate[age]=daily_mort4;
	   
	   for (i=2;i<gps_in_file;++i){
	     l_age=(i-1)*5;
		 up_age=l_age+4;
	     mort5=(alive5[i-1]-alive5[i])/alive5[i-1];
	     daily_mort5=convert_para(mort5,5*tsteps_pyr);
	/*	 printf("gp=%d  l_age=%d up_age=%d mort5=%10.6e  daily_mort5=%10.6e\n",
		              gp,l_age,up_age,mort5,daily_mort5);*/
		 for (age=l_age;age<=up_age;++age){ 
     		if (age<95) m_rate[age]=daily_mort5;
		 }	
	   }
//       printf("alive5[gps_in_file-1]=%10.6e",alive5[gps_in_file-1]);	   
	   mort95t99=(alive5[gps_in_file-1]-alive100t120)/alive5[gps_in_file-1];
//	   printf("mort95t99=%10.6e\n",mort95t99);
	   daily_mort95t99=convert_para(mort95t99,5*tsteps_pyr);
//	   printf("daily_mort95t99=%10.6e\n",daily_mort95t99);
       for (age=95;age<=99;++age)
         m_rate[age]=daily_mort95t99;			 

    }	   
    p=fgets(cur_lin,vln_lngth,ifp);
 }
 fclose(ifp);
 
 printf("The following is the daily mortality rate\n");
 for (age=min_age;age<=maxage;++age)
   printf("[%d] %10.6e \n",age,m_rate[age]);
 
// exit(1);
free_dvector(alive5,1,gps_in_file);
}
   
   
void get_impaspfert(char aspfert_file[],double **yr_imp_aspfert,int country_code,
                    int up_age,int min_year,int fin_year,int max_agefert){
/* This assigns the age-specific fertility rate from the files provided by VIMC */
						
						
int loc,low_age,high_age,low_year,high_year;
int age;
int done_country,yy,year;
int use_highyear,max_highyear;
double iasp;
char cntry[strngln],abbrev[strngln],gend[strngln],*p,cur_lin[vln_lngth]; // ,aspfert_file[strngln];
FILE *ifp;  

if ( (ifp=fopen(aspfert_file,"r")) == NULL) {
    printf("\nCannot open aspfert_file %s - bye!",aspfert_file);
    exit(1);
}	
 printf("entered get_impaspfert\n");
 p=fgets(cur_lin,vln_lngth,ifp);
 
 printf("cur_lin[0]=%c\n",cur_lin[0]);
 while (cur_lin[0]=='*')  {
    p=fgets(cur_lin,vln_lngth,ifp); printf("*");fputs(p,stdout);
    printf("cur_lin[0]=%c\n",cur_lin[0]);
 }
 done_country=0;
 max_highyear=0;
 while ((cur_lin[0] != '!' ) && (done_country==0) ){  // Note end of file denoted by ! not by Z, as names of some countries starts with Z
    sscanf(p,"%d%s%d%d%d%s%lf",	
    	&loc,abbrev,&low_age,&high_age,&low_year,gend,&iasp);
/*    printf("loc=%d abbrev=%s low_age=%d high_age=%d low_year=%d iasp=%10.6f\n",
            loc,abbrev,low_age,high_age,low_year,iasp);*/
	high_year=low_year+4;		
	if ((loc==country_code) && (done_country==0) && (low_year>=min_year) ){
	   use_highyear=min(high_year,fin_year);
	   for (yy=low_year;yy<=use_highyear;++yy){
	      for (age=low_age;age<=high_age;++age){
		     yr_imp_aspfert[yy][age]=iasp;
		  }
       }	
       if (use_highyear>=max_highyear) max_highyear=use_highyear;	   
	   if ((high_year>=fin_year) && (high_age>=max_agefert))  done_country=1;
	}	 
//	printf("done_country=%d\n",done_country);
    p=fgets(cur_lin,vln_lngth,ifp);
 }
 fclose(ifp);
 
 for (year=max_highyear+1;year<=fin_year;++year)
   for (age=0;age<=up_age;++age)
	 yr_imp_aspfert[year][age]=yr_imp_aspfert[max_highyear][age];
 
 printf("The following is the age-specific fertility rate\n");
for (year=min_year;year<=fin_year;++year){
  printf("%d\t",year);
  for (age=0;age<=up_age;++age)
    printf("%10.6e\t",yr_imp_aspfert[year][age]);
  printf("\n");
}

}

void adj_calc_beta(double a_test[],double beta[],double prop_age[],double infous_period_days,double total_popn_start,int age_cb,
                 int up_age,double k_val[]){
/* THis function is used to calculate the values beta[1] and beta[2] from the force of infection that's held in a_test[].
   beta[1] is the child-child contact parameter; beta[2] is the adult-adult contact parameter */


double infous_y,infous_o,ave_infous,total_popn,popage,b_rate;
double N_mat,N_y,N_o,sus_o,sus_y,foi_y,foi_o,psus_cb;
float k;
int i,age,num_ktests;

foi_y= a_test[1];
foi_o= a_test[2];

k=0.7;

printf("foi_y=%10.6e foi_o=%10.6e\n",foi_y,foi_o);

sus_y=exp(-foi_y*0.5)*prop_age[0]*0.5;
for (age=1;age<=age_cb;++age){
  sus_y+=exp(-foi_y*(age-0.5))*prop_age[age];
}
sus_y*=total_popn_start;
 printf("sus_y=%10.6e\n",sus_y);

psus_cb=exp(-foi_y*(age_cb-0.5));
sus_o=0.0;
for (age=age_cb+1;age<up_age;++age){
  sus_o+=psus_cb*exp(-foi_o*(age-age_cb))*prop_age[age];
}
sus_o*=total_popn_start;
 printf("psus_cb=%10.6e sus_o=%10.6e\n",psus_cb,sus_o);


infous_y=sus_y*foi_y*infous_period_days/365;
infous_o=sus_o*foi_o*infous_period_days/365;
printf("infous_y=%10.6e infous_o=%10.6e\n",infous_y,infous_o);

beta[2]=foi_o/(k*infous_y+infous_o);
beta[1]=(foi_y-beta[2]*infous_o*k)/infous_y;
beta[1]/=365.0; beta[2]/=365.0;

printf("beta[1]=%10.6e beta[2]=%10.6e\n",beta[1],beta[2]);

num_ktests=70000;

if ( (beta[1]<0) || (beta[2]<0) ) {
  for (i=1;i<=num_ktests;++i){
    k-=0.0001;
  // if ((k<0) || (k>1) ){
    // printf("!!! error k<0 in get_beta funtion\n");
	// exit(1);
  // }
    beta[2]=foi_o/(k*infous_y+infous_o);
    beta[1]=(foi_y-beta[2]*infous_o*k)/infous_y;
    beta[1]/=365.0; beta[2]/=365.0;
 //   printf("in for loop i=%d k=%10.4e beta1=%10.6e beta[2=%10.6e \n",i,k,beta[1],beta[2]);
	if ( ( (beta[1]>0) && (beta[2]>0) && (k>0) ) || (k<0) ) i=num_ktests+5000;
  }	
}  

fprintf(stderr,"k=%10.4e\n",k);

// exit(1);
if ((k<0) || (beta[1]<0) || (beta[2]<0)){
  fprintf(stderr," Setting k multiplicatively until have +ive values for beta\n");
  k=0.1; // 1e-9;

  beta[2]=foi_o/(k*infous_y+infous_o);
  beta[1]=(foi_y-beta[2]*infous_o*k)/infous_y;
  beta[1]/=365.0; beta[2]/=365.0;

  while ( (beta[2]<0) || (beta[1]<0) ) {
    k/=10.0;
    beta[2]=foi_o/(k*infous_y+infous_o);
    beta[1]=(foi_y-beta[2]*infous_o*k)/infous_y;
    beta[1]/=365.0; beta[2]/=365.0;
    // printf("here k=%10.8e beta[1]=%10.6e beta[2]=%10.6e\n",k,beta[1],beta[2]);
  }
}
printf("post k=%10.4e beta1=%10.6e beta[2=%10.6e \n",k,beta[1],beta[2]);
fprintf(stderr,"k=%10.4e\n",k);

*k_val=k;


}



void get_bstraps_and_betas_sing_2015(int age_cb,int up_age,double foi_ptsus_y[],double foi_ptsus_o[],double **equm_ann_foi,double **beta_vals,
                             double prop_age[],double infous_period_days,double total_popn_start,double k_val[],
                             int reqd_bsreplicate, char use_bsfile[], char sumfile[]){
								 
/*  This function reads in the equilibrium force of infection from the file use_bsfile (either a file with the extension *.mbio, *.med or *.ave.  
    It then calls up the function adj_calc_beta to calculate the contact (beta) parameters. 
	These files have multiple uses (beyond those for VIMC) and so they hold columns in addition tothose for the force of infection.  The 
	following code is written so that only the relevant columns are extracted
	
	*/
				
			
double *ipy,*ipHK_preg,*CpHK_lbths;
char date_created[60],model[2],dummy[3];
char *p,cur_lin[bsline_lngth];
int int_dset,used_bs,low_fit_num,high_fit_num,bfit_num;
int cur_bstrap;
int failed_calc,sum_failed_calcns;
int u_b,fit_num;
int age_gp,gp;
int lineNo = 0, found_bsnum;
double fin_blhood,fin_dev,*store_dev,acr_risk,fptsus_y,fptsus_o,sens;
char bestbstraps_file[strgln_long],bs_source[strngln];	
FILE *ifp,*ofp;

printf("entered get_bstraps\n");
 
  strcpy( bestbstraps_file, "foi_bootstraps/" );
  strcat( bestbstraps_file, use_bsfile );
  
  printf("!!!File containing bootstraps for force of infection: %s\n",bestbstraps_file);

  ofp=fopen(sumfile,"a");
  fprintf(ofp,"bootstraps_file:%s;",bestbstraps_file);
  fclose(ofp);
				
	if ( (ifp=fopen(bestbstraps_file,"r")) == NULL) {
      printf("\nCannot open bestbstraps file - bye!");
      exit(1);
    }
    p=fgets(cur_lin,line_lngth,ifp);
    printf("cur_lin[0]=%c\n",cur_lin[0]);
    while (cur_lin[0]=='*')  {
        p=fgets(cur_lin,bsline_lngth,ifp); fputs(p,stdout);
        printf("cur_lin[0]=%c\n",cur_lin[0]);
    }
	cur_bstrap=1;
	found_bsnum=0; 
    while ((cur_lin[0] != 'Z' ) && (found_bsnum==0)){ 	
        sscanf(p,"%s%s%d%d%d%d%d%lf%lf%lf%lf%lf",
	            date_created,model,&int_dset,&used_bs,&low_fit_num,&high_fit_num,&bfit_num,&fin_blhood,&fin_dev,&acr_risk,
				&fptsus_y,&fptsus_o);
		lineNo++;
		if( used_bs == 0 ){ 
			if( lineNo > 1 ){ 
				printf("\nUnexpected bootstrap replicate 0 was found in line %d - bye!", lineNo );
				exit( EXIT_FAILURE );
			}
			lineNo = 0;
		}
          
		  printf("date_created=%s model=%s int_dset=%d used_bs=%d\n",date_created,model,int_dset,used_bs);
	      printf("used_bs=%d low_fit_num=%d fin_dev=%10.6e\n",used_bs,low_fit_num,fin_dev);
	  
    	  printf("date_created=%s model=%s int_dset=%d used_bs=%d\n",date_created,model,int_dset,used_bs);
	      printf("used_bs=%d low_fit_num=%d fin_dev=%10.6e\n",used_bs,low_fit_num,fin_dev);
	      u_b=used_bs; fit_num=low_fit_num;
	
          if (reqd_bsreplicate == 0 || reqd_bsreplicate == lineNo ){ // for minimum changes, just assigning to index=1 for the foi values
    	      foi_ptsus_y[cur_bstrap]=fptsus_y;
	          foi_ptsus_o[cur_bstrap]=fptsus_o;
	  
	          equm_ann_foi[cur_bstrap][1]=fptsus_y*1e-3;
	          equm_ann_foi[cur_bstrap][2]=fptsus_o*1e-3;	

              adj_calc_beta(equm_ann_foi[cur_bstrap],beta_vals[cur_bstrap],prop_age,infous_period_days,total_popn_start,age_cb,up_age,
			              &k_val[cur_bstrap]);
              printf("exited calc_beta\n");		  
			  found_bsnum=1;
		}									   
											   
										   
     	p=fgets(cur_lin,bsline_lngth,ifp);										   

    }

   fclose(ifp);
   
	}


void setup_propage(int num_days,int num_tsteps_pyr,int tsteps_pday,float tstep_size,int start_sim,int fin_year,int up_age,double prop_age[],
                 double **m_rate,float ann_brate[]){
// THis function calculates the proportion of the population that's in each age stratum. prop_age is used to 
// calculate the beta values in the code					 
					 
					 
double total_popn,**popage,*births_new;
int year,day,age,sex,tstep_in_year,tstep;

void get_births_brate(int year,float ann_brate,double **sing_pop,int up_age,double *births_new);

popage=dmatrix(0,1,0,up_age);
births_new=dvector(0,1);
for (sex=0;sex<=1;++sex){
  births_new[sex]=0.0;
  for (age=0;age<=up_age;++age)
    popage[sex][age]=100;
}
printf("start_sim=%d fin_year=%d num_days=%d num_tsteps_pyr=%d\n",start_sim,fin_year,num_days,num_tsteps_pyr);
for (year=start_sim;year<= fin_year ;++year){
  tstep_in_year=0;
  for (day=0;day<=num_days-1;++day) {
    for (tstep=0;tstep<tsteps_pday;++tstep){ 
      if (tstep_in_year<(num_tsteps_pyr-1)){
	    for (sex=0;sex<=1;++sex){
	      for (age=up_age;age>=0;--age){
            popage[sex][age]-=popage[sex][age]*m_rate[sex][age]*tstep_size;		
		//	printf("sex=%d age=%d popage=%10.6e\n",sex,age,popage[sex][age]);
		  }	
	    }
	  } 
      if (tstep_in_year==(num_tsteps_pyr-1)) {
	  //  printf("tstep_in_year=%d\n",tstep_in_year);
	    get_births_brate(year,ann_brate[year],popage,up_age,births_new);
	//	printf("births_new[0]=%10.6e births_new[1]=%10.6e\n",births_new[0],births_new[1]); 
		for (sex=0;sex<=1;++sex){
	      for (age=up_age;age>0;--age)
            popage[sex][age]=popage[sex][age-1]*(1-m_rate[sex][age-1]*tstep_size);
          popage[sex][0]=births_new[sex];
        }		  
	  }
	++tstep_in_year;  
    }
  }
}
total_popn=0.0;
for (sex=0;sex<=1;++sex){
 for (age=0;age<=up_age;++age){
   total_popn+=popage[sex][age];
 }
}
printf("total_popn=%10.6e\n",total_popn);
 for (age=0;age<=up_age;++age){
   prop_age[age]=(popage[0][age]+popage[1][age])/total_popn;
   printf("age=%d %10.6e %10.6e %10.6e %10.6e\n",age,popage[0][age],popage[1][age],prop_age[age],prop_age[age]);
 }
free_dmatrix( popage,0,1,0,up_age);
free_dvector(births_new,0,1);
 
}

void get_prop_mat_and_y(double *prop_mat,double *prop_y,double *prop_age,int age_cb,int up_age){
/* This function gets the proportion of the population at the start that's 
  made up by children with maternal immunity (prop_mat) and by children (prop_y)*/
	
	
	
double p_young;
int age;

  *prop_mat=p_young=prop_age[0]*0.5; 
  for (age=1;age<=age_cb;++age) p_young+=prop_age[age];
  printf("p_young=%10.6e\n",p_young);
  *prop_y=p_young;
  printf("*prop_mat=%10.6e *prop_y=%10.6e\n",*prop_mat,*prop_y);
}




void imp_readin_sia_cov(char sia_details_file[],int intended_c_num,int intended_c_code,
                 double **agesp_scov_mat,double **agesp_scov_9mths,double ***agesp_scov,
                 int min_year,int max_year,int fin_gavi,int min_age,int maxage,
				 double scaleFactor ){			 
/* This function reads in the SIA coverage by age and over time provided by VIMC*/	

	
int cc,yy,high_age;
double age_low,target,cov;
int age,year,done_country,gender;

char scenario[strngln],abbrev[strngln],*p,cur_lin[vln_lngth];
char set_name[strngln],vaccine[strngln],gavi_support[strngln],activity_type[strngln];
char age_range_verb[strngln];
FILE *ifp;  

  if ( (ifp=fopen(sia_details_file,"r")) == NULL) {
    printf("\nCannot open sia_details_file %s - bye!",sia_details_file);
    exit(1);
 } 
 printf("entered imp_readin_sia_cov intended_c_code=%d intended_c_num=%d\n",intended_c_code,intended_c_num);
 p=fgets(cur_lin,vln_lngth,ifp);
printf("cur_lin[0]=%c\n",cur_lin[0]);
 while (cur_lin[0]=='*')  {
    p=fgets(cur_lin,vln_lngth,ifp);
	fputs(p,stdout);
    printf("cur_lin[0]=%c\n",cur_lin[0]);
 }
 done_country=0;

 while ((cur_lin[0] != '!' ) && (done_country==0) ){  // Note end of file denoted by ! not by Z, as names of some countries starts with Z
   sscanf(p,"%d%s%s%s%s%s%s%d%lf%d%s%lf%lf%d",
           &cc,scenario,set_name,vaccine,gavi_support,activity_type,abbrev,
                              &yy,&age_low,&high_age,age_range_verb,&target,&cov,&gender);
/*    printf("cc=%d scenario=%s set_name=%s vaccine=%s gavi_support=%s activity_type=%s abbrev=%s yy=%d age_low=%10.2f high_age=%d age_range_verbatim=%s target=%10.6e vcov=%10.6e\n",
           cc,scenario,set_name,vaccine,gavi_support,activity_type,abbrev,
		   yy,age_low,high_age,age_range_verb,target,cov);*/
		  // exit(1);
	if ((cc==intended_c_code) && (yy>=min_year) && (yy<=max_year) && (done_country==0)  ){
	   cov*=scaleFactor;                 // EV 27.12.17 - this line swapped with subsequent line to avoid coverage of >100%
	   if (cov>=1.00) cov=0.999;    
//	   printf("yy=%d\n",yy);
	   if (gender==2){
	   if (age_low<1){
		 if  ((age_low==0.5)  || (age_low==0)) agesp_scov_mat[yy][0]=agesp_scov_mat[yy][1]=cov; 
		 if (age_low==0.75)  agesp_scov_9mths[yy][0]=agesp_scov_9mths[yy][1]=cov;
	     for (age=1;age<=high_age;++age) 
	       agesp_scov[yy][0][age-1]=agesp_scov[yy][1][age-1]=cov;
       }		 
       else {
	//     printf("in here lowage=%f high_age=%d cov=%10.6e\n",age_low,high_age,cov);
	     for (age=age_low;age<=high_age;++age)
	       agesp_scov[yy][0][age-1]=agesp_scov[yy][1][age-1]=cov;   
	   }
	   }
	   else{
		   if (age_low<1){
			   if  ((age_low==0.5)  || (age_low==0)) agesp_scov_mat[yy][gender]= cov; 
		 if (age_low==0.75)  agesp_scov_9mths[yy][gender]= cov;
	     for (age=1;age<=high_age;++age) 
	       agesp_scov[yy][gender][age-1]= cov;
	   }
	   else{
	//	   printf("in here lowage=%f high_age=%f cov=%10.6e\n",age_low,high_age,cov);
	     for (age=age_low;age<=high_age;++age)
	       agesp_scov[yy][gender][age-1]= cov;
	   }
	   }
	  if (yy==max_year) done_country=1;  
	 }
   p=fgets(cur_lin,vln_lngth,ifp);
 }
 fclose(ifp); 
}
				 
void imp_readin_rcv_cov_dose1(char rcv_cov_file[],int intended_c_num,int intended_c_code,
                 double **rcv_cov_9mths, int min_year,int max_year,int fin_gavi,
				 double scaleFactor ){			 
				 
/* This function reads in the RCV1 coverage  over time provided by VIMC*/					 
				 
				 				 
int cc,yy,high_age;
double age_low,target,cov;
int age,year,done_country,gender;

char scenario[strngln],abbrev[strngln],*p,cur_lin[vln_lngth];
char set_name[strngln],vaccine[strngln],gavi_support[strngln],activity_type[strngln];
char age_range_verb[strngln];
FILE *ifp;  

  if ( (ifp=fopen(rcv_cov_file,"r")) == NULL) {
    printf("\nCannot open rcv_cov_file %s - bye!",rcv_cov_file);
    exit(1);
 } 
 printf("entered imp_readin_sia_cov intended_c_code=%d intended_c_num=%d\n",intended_c_code,intended_c_num);
 p=fgets(cur_lin,vln_lngth,ifp);
printf("cur_lin[0]=%c\n",cur_lin[0]);
 while (cur_lin[0]=='*')  {
    p=fgets(cur_lin,vln_lngth,ifp);
	fputs(p,stdout);
    printf("cur_lin[0]=%c\n",cur_lin[0]);
 }
 done_country=0;

 while ((cur_lin[0] != '!' ) && (done_country==0) ){  // Note end of file denoted by ! not by Z, as names of some countries starts with Z
   sscanf(p,"%d%s%s%s%s%s%s%d%lf%d%s%lf%lf%d",
           &cc,scenario,set_name,vaccine,gavi_support,activity_type,abbrev,
                              &yy,&age_low,&high_age,age_range_verb,&target,&cov,&gender);
/*    printf("cc=%d scenario=%s set_name=%s vaccine=%s gavi_support=%s activity_type=%s abbrev=%s yy=%d age_low=%10.2f high_age=%d age_range_verbatim=%s target=%10.6e vcov=%10.6e\n",
           cc,scenario,set_name,vaccine,gavi_support,activity_type,abbrev,
		   yy,age_low,high_age,age_range_verb,target,cov);*/
	if ( (age_low>0) || (high_age>0) ) {
		printf("!!! Error in imp_readin_rcv_cov...age_low=%10.2f high_age=%d but both should equal zero...\nExiting program",
		          age_low,high_age);
		exit(1);
	}	   		
		  // exit(1);
	if ((cc==intended_c_code) && (yy>=min_year) && (yy<=max_year) && (done_country==0)  ){
	   cov*=scaleFactor;		      // EV 27.12.17 - this line swapped with subsequent line to avoid coverage of >100%
	   if (cov>=1.00) cov=0.999;
 	   printf("in yy =%d\n",yy);
	   if (gender==2) rcv_cov_9mths[yy][0]=rcv_cov_9mths[yy][1]=cov;
	   else rcv_cov_9mths[yy][gender]=cov;   
	   if (yy==max_year) done_country=1;  
	 }
   p=fgets(cur_lin,vln_lngth,ifp);
 }
 fclose(ifp); 
				 }


void imp_readin_rcv_cov_dose2(char rcv_cov_file[],int intended_c_num,int intended_c_code,
                 double ***rcv_cov_dose2, int min_year,int max_year,int fin_gavi,
				 double scaleFactor ){		
/* This function reads in the RCV2 coverage  over time provided by VIMC*/	
				 
				 				 
int cc,yy,high_age;
double age_low,target,cov;
int age,year,done_country,gender;

char scenario[strngln],abbrev[strngln],*p,cur_lin[vln_lngth];
char set_name[strngln],vaccine[strngln],gavi_support[strngln],activity_type[strngln];
char age_range_verb[strngln];
FILE *ifp;  

  if ( (ifp=fopen(rcv_cov_file,"r")) == NULL) {
    printf("\nCannot open rcv_cov_file %s - bye!",rcv_cov_file);
    exit(1);
 } 
 printf("entered imp_readin_sia_cov intended_c_code=%d intended_c_num=%d\n",intended_c_code,intended_c_num);
 p=fgets(cur_lin,vln_lngth,ifp);
printf("cur_lin[0]=%c\n",cur_lin[0]);
 while (cur_lin[0]=='*')  {
    p=fgets(cur_lin,vln_lngth,ifp);
	fputs(p,stdout);
    printf("cur_lin[0]=%c\n",cur_lin[0]);
 }
 done_country=0;

 while ((cur_lin[0] != '!' ) && (done_country==0) ){  // Note end of file denoted by ! not by Z, as names of some countries starts with Z
   sscanf(p,"%d%s%s%s%s%s%s%d%lf%d%s%lf%lf%d",
           &cc,scenario,set_name,vaccine,gavi_support,activity_type,abbrev,
                              &yy,&age_low,&high_age,age_range_verb,&target,&cov,&gender);
/*    printf("cc=%d scenario=%s set_name=%s vaccine=%s gavi_support=%s activity_type=%s abbrev=%s yy=%d age_low=%10.2f high_age=%d age_range_verbatim=%s target=%10.6e vcov=%10.6e\n",
           cc,scenario,set_name,vaccine,gavi_support,activity_type,abbrev,
		   yy,age_low,high_age,age_range_verb,target,cov);*/

	if ((cc==intended_c_code) && (yy>=min_year) && (yy<=max_year) && (done_country==0)  ){
	   cov*=scaleFactor;               
       if (cov>=1.00) cov=0.999;
	   printf("in yy =%d\n",yy);
	   if (gender==2){
	   for (age=age_low;age<=high_age;++age)
		   rcv_cov_dose2[yy][0][age-1]=rcv_cov_dose2[yy][1][age-1]=cov;   // EV edited 13.01.20 - made consistent with the implementation for SIAs. RCV2 is carried out at age 2 years, 
	                                                                       // so adjustment to use age-1 rather than age
	   }
	   else {
		   for (age=age_low;age<=high_age;++age)
			   rcv_cov_dose2[yy][gender][age-1]=cov;   // EV edited 13.01.20 - made consistent with the implementation for SIAs. RCV2 is carried out at age 2 years, 
	                                                                       // so adjustment to use age-1 rather than age
	   }
	   if (yy==max_year) done_country=1;  
	 }
   p=fgets(cur_lin,vln_lngth,ifp);
 }
 fclose(ifp); 
				 }

				 
				 

void imp_assign_include_sia_and_vaccn(char sumfile[], char sia_details_file[], char rcv1_cov_file[], 
				char rcv2_cov_file[], int intended_c_num, int intended_c_code, 
				double **agesp_scov_mat, double **agesp_scov_9mths, double ***agesp_scov, 
				double **rcv_cov_9mths, double ***rcv_cov_dose2,int min_year, int max_year, int fin_gavi, int min_age, 
				int maxage, 
				double scaleFactor ){
					
/* This function calls up the relevant functions to read in the SIA, RCV1 and RCV2 coverage from the files provided by VIMC*/
					

FILE *ofp;

printf("1st entered readin_vacc\n");		

ofp=fopen(sumfile,"a");
printf("post open\n");

fprintf(ofp,"sia_details_file:%s;rcv_include_file:%s;rcv_cov_file:%s",sia_details_file,rcv1_cov_file,rcv2_cov_file);
printf("post writing\n");
fclose(ofp);

printf("entered readin_vacc\n");		

imp_readin_sia_cov( sia_details_file, intended_c_num, intended_c_code, agesp_scov_mat,
						agesp_scov_9mths,agesp_scov, min_year, max_year, fin_gavi, min_age,
						maxage, scaleFactor );	// EV 10.10.17

		 
		
imp_readin_rcv_cov_dose1( rcv1_cov_file, intended_c_num, intended_c_code, rcv_cov_9mths, min_year, max_year,
				fin_gavi, scaleFactor ); // EV 12.10.17
imp_readin_rcv_cov_dose2( rcv2_cov_file, intended_c_num, intended_c_code, rcv_cov_dose2, min_year, max_year,
				fin_gavi, scaleFactor ); // EV 13.11.17
				
printf("completed here\n");
}




void get_para(char infile[],double para[],int max_rep){
/* This function reads in all possible values between 0 and max_rep for each of the parameters that are being varied*/
	
	
double para_val;	
int rep,done_reps;
FILE *ifp;
char *p,cur_lin[vln_lngth];

if ( (ifp=fopen(infile,"r")) == NULL) {
    printf("\nCannot open parameter file %s - bye!",infile);
    exit(1);
}
p=fgets(cur_lin,vln_lngth,ifp);
	
 while (cur_lin[0]=='*')  {
    p=fgets(cur_lin,vln_lngth,ifp);fputs(p,stdout);
    printf("cur_lin[0]=%c\n",cur_lin[0]);
 }
done_reps=0;
while (done_reps<max_rep){
  sscanf(p,"%lf",&para_val);
  ++done_reps;
  para[done_reps]=para_val;
  p=fgets(cur_lin,vln_lngth,ifp);
}
for (rep=1;rep<=max_rep;++rep)
  printf("rep=%d para=%10.6e\n",rep,para[rep]);
	
}

