# include <stdio.h>
# include <math.h>
# include <stdlib.h>
# include <time.h>

# define strngln 50
# define strgln_long 200
# define bsline_lngth 1500
# define vfile_lngth 65
# define ln_lngth 1500
# define vln_lngth 5000
# define dum_dpts 12
# define line_lngth 500
# define line_lngth 500

# define max(x,y)  (((x) > (y)) ? (x) : (y))
# define min(x,y)  (((x) < (y)) ? (x) : (y))


double **dmatrix(int nrl, int nrh, int ncl, int nch);
double *dvector(int nl, int nh);
float **matrix(int nrl, int nrh, int ncl, int nch);
double ***d3tensor(int nrl, int nrh, int ncl, int nch, int ndl, int ndh);
void free_vector(float *v, int nl,int nh);
void free_dvector(double *v, int nl,int nh);
void free_dmatrix(double **m, int nrl, int nrh, int ncl, int nch);
void free_d3tensor(double ***t, int nrl, int nrh, int ncl, int nch,
              int ndl, int ndh);




void introduce_importations(int maxage,double *sus,double *infous, float frac_import){
// 050819 - copied from reinitialize_frac_sus_and_infous in paed flu code.  Bringing in importations	
	
double *seed;
int age;

 /* this reseeds the infectious popn and adjusts the no of susceptible 
                                                       individuals at the start of each year */

													   
   seed=dvector(0,maxage);
   for (age=0;age<=maxage;++age) seed[age]=0.0;
   for (age=5;age<=50;++age) seed[age]= sus[age]*frac_import;  // 1500; edited out 050819

   for (age=0;age<=maxage;++age) infous[age]+=seed[age];
   for (age=0;age<=maxage;++age){
     sus[age]-=seed[age];
/*     incub[age]=0.0;*/
/*     printf("%2d %10.6e %10.6e %10.6e %10.6e %10.6e %10.6e\n",age,num_prot_vacc,sus[age],incub[age],infous[age],immune[age],vaccinated[age]);*/
   }
   free_dvector(seed,0,maxage);
}



					 
			  
			  
void update_compartments(int sex,int age,int year,int day,int tstep_in_year,int durn_mat_tsteps,
               double **sus,double **incub,double **infous,double **immune,double *lambda,			   
			   double **sing_inf_pyr,double **sing_inf_pday,
               double **m_rate,float tstep_size,double infous_rate_pday,double rec_rate_pday,
			   double *effvacc_18mths){
				   
/* This function updates the compartments at any time step which isn't at the end of the year */
				   
			   
double pre_mort,post_mort,post_mort_check,newly_inftd,new_infous,new_vacc,new_rem;
double sus_deaths,incub_deaths,infous_deaths,imm_deaths;
			  
pre_mort= sus[sex][age]+incub[sex][age]+infous[sex][age]+immune[sex][age];
post_mort=pre_mort*(1-m_rate[sex][age]*tstep_size);

newly_inftd=lambda[age]*sus[sex][age]*tstep_size;
new_infous=incub[sex][age]*infous_rate_pday*tstep_size;
new_rem=infous[sex][age]*rec_rate_pday*tstep_size;

sus_deaths=m_rate[sex][age]*sus[sex][age]*tstep_size;
incub_deaths=m_rate[sex][age]*incub[sex][age]*tstep_size;
infous_deaths=m_rate[sex][age]*infous[sex][age]*tstep_size;
imm_deaths=m_rate[sex][age]*immune[sex][age]*tstep_size;

if ( (tstep_in_year==durn_mat_tsteps) && (age==1)) new_vacc=effvacc_18mths[sex]*sus[sex][age];
            else new_vacc=0.0;    

sus[sex][age]=sus[sex][age]-newly_inftd-sus_deaths-new_vacc;
incub[sex][age]=incub[sex][age]+newly_inftd-new_infous-incub_deaths;
infous[sex][age]=infous[sex][age]+new_infous-new_rem-infous_deaths;
immune[sex][age]=immune[sex][age]+new_rem-imm_deaths+new_vacc;
sing_inf_pyr[sex][age]+=newly_inftd;
sing_inf_pday[sex][age]+=newly_inftd;	

post_mort_check=sus[sex][age]+incub[sex][age]+infous[sex][age]+immune[sex][age];
         //   if (year>=yr_start_store) printf("age=%d pre=%10.6e post_check=%10.6e\n",age,pre_mort,post_mort_check);
if (fabs(post_mort_check-post_mort)>0.00005){
    printf("age=%d deaths incorrectly incorporated in rubtd*! Exiting program\n");
    printf("year=%d tstep_in_year=%d day=%d age=%d pre_mort=%10.6e post_mort_check=%10.6e sex=%d m_rate=%10.6e\n",
				             year,tstep_in_year,day,age,pre_mort,post_mort_check,sex,m_rate[sex][age]);
    exit(1);
}
			
if (new_vacc>0.0) printf("year=%d tstep_in_year=%d age=%d vacc=%10.6e\n",year,tstep_in_year,age,new_vacc);

}


void update_fyol_compartments(int sex,int year,int day,int tstep_in_year,int durn_mat_tsteps,int durn_9mths_tsteps,
               double mat[],double **sus,double **incub,double **infous,double **immune,double *lambda,			   
			   double **sing_inf_pyr,double **sing_inf_pday,
               double **m_rate,float tstep_size,double infous_rate_pday,double rec_rate_pday,
			   double *effvacc_mat,double *effvacc_9mths){

/* This function updates the compartments relating to the first year of life at any time step which isn't at 
   the end of the year */				   
			   
double newly_inftd0,new_infous,new_rem,new_immune0;
double sus_deaths0,incub_deaths0,infous_deaths0,imm_deaths0;
double pre_mort,post_mort,post_mort_check;			   
			   
if (tstep_in_year<durn_mat_tsteps){
  mat[sex]*=(1-m_rate[sex][0]*tstep_size);
  sus[sex][0]=incub[sex][0]=infous[sex][0]=immune[sex][0]=newly_inftd0=0.0;
}
if (tstep_in_year>=durn_mat_tsteps){
  new_infous=incub[sex][0]*infous_rate_pday*tstep_size;
  new_rem=infous[sex][0]*rec_rate_pday*tstep_size;

  if (tstep_in_year==durn_mat_tsteps){
    newly_inftd0=mat[sex]*lambda[0]*(1-effvacc_mat[sex])*tstep_size;
    sus[sex][0]=mat[sex]*(1-effvacc_mat[sex])-newly_inftd0;
    incub[sex][0]=newly_inftd0;
    infous[sex][0]=0.0;      
    immune[sex][0]=mat[sex]*effvacc_mat[sex];
    mat[sex]=0.0;
  }
  if (tstep_in_year>durn_mat_tsteps){
    if (tstep_in_year==durn_9mths_tsteps) new_immune0=sus[sex][0]*effvacc_9mths[sex];
    else  new_immune0=0.0;

    pre_mort= sus[sex][0]+incub[sex][0]+infous[sex][0]+immune[sex][0];
    post_mort=pre_mort*(1-m_rate[sex][0]*tstep_size);

    newly_inftd0=lambda[0]*sus[sex][0]*tstep_size;
    sus_deaths0=m_rate[sex][0]*sus[sex][0]*tstep_size;
    incub_deaths0=m_rate[sex][0]*incub[sex][0]*tstep_size;
    infous_deaths0=m_rate[sex][0]*infous[sex][0]*tstep_size;
    imm_deaths0=m_rate[sex][0]*immune[sex][0]*tstep_size;

    sus[sex][0]=sus[sex][0]-newly_inftd0-sus_deaths0-new_immune0;
    incub[sex][0]=incub[sex][0]+newly_inftd0-new_infous-incub_deaths0;
    infous[sex][0]=infous[sex][0]+new_infous-new_rem-infous_deaths0;
    immune[sex][0]=immune[sex][0]+new_rem-imm_deaths0+new_immune0; 
			  
    post_mort_check=sus[sex][0]+incub[sex][0]+infous[sex][0]+immune[sex][0];

    if (fabs(post_mort_check-post_mort)>0.00005){
      printf("deaths incorrectly incorporated! Exiting program\n");
      printf("age=%d pre_mort=%10.6e post_mort_check=%10.6e\n",0,pre_mort,post_mort_check);
      exit(1);
    }
  }		
  sing_inf_pyr[sex][0]+=newly_inftd0;
  sing_inf_pday[sex][0]+=newly_inftd0;
}     

}
			  

void nounvacc_vacc_store_brate_new_end_of_year(double **sus,double **incub,double **infous,double **immune,double *lambda,
                 double **effvacc_sus,
                 double mat[],double effvacc_mat[],double **sing_inf_pday,double **sing_inf_pyr,double **m_rate,
                  int up_age,double infous_rate_pday,double rec_rate_pday,float tstep_size, 
                 int year,float ann_brate,double **sing_pop){
					 
// This function  updates the compartments at the end of the year, when vaccination and new births occur
					 
int age,sex,yy;
double newly_inftd;
double *births_new;

void get_births_brate(int year,float ann_brate,double **sing_pop,int up_age,double *births_new);

/* This moves all individuals in a given age group into the next subsequent age group at the end of the year *and adds in newborns */

// printf("entered vacc_store_end_of_year \n",sex); 

births_new=dvector(0,1);

	get_births_brate(year,ann_brate,sing_pop,up_age,births_new);   // this gets the number of births, using the annual birth rate and population size

for (sex=0;sex<=1;++sex){
  for (age=up_age;age>0;--age){
    sus[sex][age]=sus[sex][age-1]*(1-effvacc_sus[sex][age-1])*(1-lambda[age-1]*tstep_size-m_rate[sex][age-1]*tstep_size);	
    incub[sex][age]=incub[sex][age-1]+ lambda[age-1]*tstep_size*(1-effvacc_sus[sex][age-1])*sus[sex][age-1]
                                     - incub[sex][age-1]*infous_rate_pday*tstep_size  - incub[sex][age-1]*m_rate[sex][age-1]*tstep_size;
    infous[sex][age]=infous[sex][age-1]+incub[sex][age-1]*infous_rate_pday*tstep_size - infous[sex][age-1]*rec_rate_pday*tstep_size
                                                              -infous[sex][age-1]*m_rate[sex][age-1]*tstep_size;
    immune[sex][age]=immune[sex][age-1] + sus[sex][age-1]*effvacc_sus[sex][age-1] + infous[sex][age-1]*rec_rate_pday*tstep_size
                                                              -immune[sex][age-1]*m_rate[sex][age-1]*tstep_size;															  

	newly_inftd=lambda[age-1]*tstep_size*(1-effvacc_sus[sex][age-1])*sus[sex][age-1];
    sing_inf_pday[sex][age-1]+=newly_inftd;
    sing_inf_pyr[sex][age-1]+=newly_inftd;
	// printf("sing inf done\n");
  }
   sus[sex][0]=incub[sex][0]=infous[sex][0]=0.0;
  immune[sex][0]=mat[sex]*effvacc_mat[sex];  /* at this stage ma[sex] should equal zero anyway...check whether too many are being vacctd */
  mat[sex]=births_new[sex];
}
   
free_dvector(births_new,0,1);
// printf("completed vacc_store_end_of_year\n");
}

void  get_max_previous_cov(int curr_age,int curr_year,int min_year_vacc,double **rcv_cov_9mths,
                 double ***rcv_cov_dose2,double *max_prev_cov,int sex){
/*  This steps through the values for rcv2 coverage for people in the birth cohort of age 
curr_age and year curr_year. If it identifies a non-zero value, then it stores that value in the parameter 
prev_rcv2_cov. It also finds the value for RCV1 coverage for the same birth cohort and stores the value in  
prev_rcv1_cov.  It then takes the maximum of the two to identify how many will then be vaccinated in an SIA 
or with RCV2. */
					 
int yrs_ago,max_yrs_ago,yr_of_rcv1,stop_yr_indx_rcv2;
double prev_rcv1_cov,prev_rcv2_cov;
	
prev_rcv2_cov=prev_rcv1_cov=0.0	;
max_yrs_ago=curr_age;
stop_yr_indx_rcv2=-9;
for (yrs_ago=1;yrs_ago<=max_yrs_ago;++yrs_ago)	{
		if (curr_year+1-yrs_ago >=min_year_vacc){   //TP 14.12.19
	if (rcv_cov_dose2[curr_year+1-yrs_ago][sex][curr_age-yrs_ago]>0){
		prev_rcv2_cov=rcv_cov_dose2[curr_year+1-yrs_ago][sex][curr_age-yrs_ago];
		stop_yr_indx_rcv2=curr_year+1-yrs_ago;
		yrs_ago=max_yrs_ago+200;
	}
		}
}
// printf("\n in get_max_previous prev_rcv2_cov=%10.6e stop_yr_indx_rcv2=%d\n",prev_rcv2_cov,stop_yr_indx_rcv2);


yr_of_rcv1=curr_year-curr_age;   // EV added 13.01.20
//printf("curr_year=%d curr_age=%d yr_of_rcv1=%d\n",curr_year,curr_age,yr_of_rcv1);
if (yr_of_rcv1>=min_year_vacc)          // EV 13.01.20
   prev_rcv1_cov=rcv_cov_9mths[yr_of_rcv1][sex];
else
   prev_rcv1_cov=0.0;
	
*max_prev_cov=max(prev_rcv1_cov,prev_rcv2_cov);

}



void get_applied_suscov(int year,int min_year_vacc,double **effvacc_sus,
                     double ***agesp_scov,double **rcv_cov_9mths,
					  double ***rcv_cov_dose2,double vacc_eff,int up_age,float pvacc_again_RCV1RCV2){
/* This function calculates the vaccination coverage among susceptible people, assuming that 
   a proportion of those vaccinated previously (pvacc_again) are vaccinated again.  The derivation of 
   the formula for the proportion vaccinated again is in the document "vaccine correlations.docx". The function 
   first calculates the proportion of people that had been vaccinated previously by calling 
   get_max_previous_cov() before applying this formula */
					  
int age,sex;
double v_s,v_p,c_p;
float pvacc_again_SIAroutine,used_pvacc_again;

pvacc_again_SIAroutine=0.5;  // EV 13.01.20 proportion of those vaccinated routinely who are vaccinated again through the SIA.  
                             // Ideally should be fed through the command line. The value is assigned here for now.

if (year<min_year_vacc){
  for (sex=0;sex<=1;++sex){
	for (age=0;age<=up_age;++age)
	  effvacc_sus[sex][age]=0.0;
  }
}
if (year>=min_year_vacc){   
  for (sex=0;sex<=1;++sex){	
	for (age=0; age<=up_age; ++age){
       get_max_previous_cov(age,year,min_year_vacc,rcv_cov_9mths,rcv_cov_dose2,&v_p,sex);   // v_p is the maximum vaccination coverage experienced by the birth cohort until now
	   v_s = max(agesp_scov[year+1][sex][age], rcv_cov_dose2[year+1][sex][age] );	// note that this will need to be sex-specific eventually
	   if (v_s>0){   
	     used_pvacc_again=pvacc_again_SIAroutine;
    	 if (agesp_scov[year+1][sex][age]>rcv_cov_dose2[year+1][sex][age])   // EV 13.01.20.  This if statement is a quick way of identifying whether we're considering routine vs SIA or                                                                    // RCV1 vs RCV2 and then assigns the appropriate value for pvacc_again to be used. 
		   used_pvacc_again=pvacc_again_SIAroutine;
     	 else 
	   	   used_pvacc_again=pvacc_again_RCV1RCV2;
       //  printf("age=%d used_pvacc_again=%10.6e\n",age,used_pvacc_again);	   
	     if (v_s< v_p*used_pvacc_again)  c_p=v_s/v_p;
	     else c_p=used_pvacc_again;
    	 effvacc_sus[sex][age]=(v_s-v_p*c_p*vacc_eff)/(1-v_p*vacc_eff);
	     if (effvacc_sus[sex][age]>1) {
		   effvacc_sus[sex][age]=1.0;
		   c_p=(v_s-1+v_p*vacc_eff)/(v_p*vacc_eff);
		//   printf("\nmodified c_p = %10.6e ", c_p);
		   if ((c_p>1) || (c_p<0) ){
			   printf("encountered problematic c_p and exiting");
			   exit(1);
		   }
	     }
	   }
	   else effvacc_sus[sex][age]=0.0;
	 //  printf("\nyear=%d\teffvacc_sus=%10.6e\tsex=%d\tage=%d\tvs=%10.6e\tvp=%10.6e\n",year,effvacc_sus[sex][age],sex,age,v_s,v_p);
   }	
  }
}
}



void get_applied_effcov(int year,int min_year_vacc,double effvacc_mat[],double effvacc_9mths[],double **effvacc_cov,
                      double **agesp_scov_mat,double **agesp_scov_9mths,double ***agesp_scov,double **rcv_cov_9mths,
					  double ***rcv_cov_dose2,double vacc_eff,int up_age){
/* This function calculates the effective vaccination coverage, taking account of thr vaccine efficacy.  If an SIA 
   is applied for an age group that also received routine coverage, the effective coverage is calculated using 
   the maximum of the SIA and routine coverage */
					  
int age,sex;
double actual_cov,actual_cov_older;

if (year<min_year_vacc){
  for (sex=0;sex<=1;++sex){
    effvacc_mat[sex]=0.0;
	effvacc_9mths[sex]=0.0;
	for (age=0;age<=up_age;++age)
	  effvacc_cov[sex][age]=0.0;
  }
}
if (year==min_year_vacc){
  for (sex=0;sex<=1;++sex){
    effvacc_mat[sex]=0.0;
	effvacc_9mths[sex]=0.0;	
	for (age=0;age<=up_age;++age) {
	  actual_cov_older = max(agesp_scov[year+1][sex][age], rcv_cov_dose2[year+1][sex][age] );	
	  effvacc_cov[sex][age] = actual_cov_older * vacc_eff;    

	}  
  }
}
if (year>min_year_vacc){  
  for (sex=0;sex<=1;++sex){

	actual_cov         = max( rcv_cov_9mths[year][sex], agesp_scov_9mths[year][sex] );
	effvacc_mat[sex]   = agesp_scov_mat[year][sex] * vacc_eff;
	effvacc_9mths[sex] = actual_cov * vacc_eff;
	// printf("year=%d rcv_cov_9mths=%10.6e  agesp_scov_9mths=%10.6e  effvacc_9mths=%10.6e\n",
	             // year,rcv_cov_9mths[year],agesp_scov_9mths[year][sex],effvacc_9mths[sex]);
	
	
	for (age=0; age<=up_age; ++age){
	   actual_cov_older = max(agesp_scov[year+1][sex][age], rcv_cov_dose2[year+1][sex][age] );	
	   effvacc_cov[sex][age] = actual_cov_older * vacc_eff;
       // printf("age=%d year+1=%d  agesp_scov=%10.6e rcv_cov_dose2=%10.6e effvacc_cov=%10.6e\n", age,year+1,
	                              // agesp_scov[year+1][sex][age],rcv_cov_dose2[year+1][age],
	                                                  // effvacc_cov[sex][age]);	   
	}	
  }
}

}


void get_births_brate(int year,float ann_brate,double **sing_pop,int up_age,double *births_new){ 
// This function gets the number of births using the birth rate and the population size

double sumpop;
int sex,age;

sumpop=0.0;

for (sex=0;sex<=1;++sex){
  for (age=0;age<=up_age;++age){
    sumpop+=sing_pop[sex][age];
  }
}

births_new[0]=births_new[1]=sumpop*ann_brate*0.5;

}



void growing_calc_foi(int age_cb,double *lambda,double **ecr,double **infous,double **sing_pop,double mat[],int up_age){
/* This calculates the force of infection */

int age,sex;
double tot_infous_y,tot_infous_o;
double sumpop_y,sumpop_o;
double ecr_yy,ecr_yo,ecr_oo,ecr_oy;
double lambda_y,lambda_o;

/*printf("entered calc_foi\n"); */

ecr_yy=ecr[0][0];
ecr_yo=ecr[0][1];
ecr_oo=ecr[1][1];
ecr_oy=ecr[1][0];

tot_infous_y=tot_infous_o=0.0;
sumpop_y=sumpop_o=0.0;

for (sex=0;sex<=1;++sex){
  for (age=0;age<=age_cb;++age){
    tot_infous_y+=infous[sex][age];
    sumpop_y+=sing_pop[sex][age];
  }
  for (age=age_cb+1;age<=up_age;++age) {
    tot_infous_o+=infous[sex][age];
    sumpop_o+=sing_pop[sex][age];
  }
}


lambda_y= (ecr_yy*tot_infous_y+ecr_yo*tot_infous_o)/sumpop_y;
lambda_o=(ecr_oy*tot_infous_y+ecr_oo*tot_infous_o)/sumpop_o;

for (age=0;age<=age_cb;++age) lambda[age]= lambda_y;
for (age=age_cb+1;age<=up_age;++age) lambda[age]= lambda_o;


}




void new_initialize_popn(int up_age,int age_cb,double *equm_annfoi,double preinf_period_days,double infous_period_days,
              int num_days,
              double *births,double *mat,double **sus,double **incub,double **infous,double **immune,double **sing_pop){
int age,sex;
double equm_annfoi_y,equm_annfoi_o;
double numsus_cb,new_infns;
  
/* The following initializes the numbers of susceptibles, infous etc at the start of the simulations. Note that the 
   number of infectious individuals is reinitialized at the start of each year (technically, 31st Aug)  */

/* printf("entered new initialize popn\n");*/

equm_annfoi_y=equm_annfoi[1];
equm_annfoi_o=equm_annfoi[2];

/* printf("in new_initialize popn equm_annfoi_y=%10.6e equm_annfoi_o=%10.6e \n",equm_annfoi_y,equm_annfoi_o);*/
for (sex=0;sex<=1;++sex){
  sus[sex][0]=  incub[sex][0]= infous[sex][0]=immune[sex][0]=0.0;
  mat[sex]=births[sex];   
   sing_pop[sex][0]=mat[sex]+sus[sex][0]+incub[sex][0]+infous[sex][0]+immune[sex][0];
  printf("sex=%d sus=%10.6e  incub=%10.6e infous=%10.6e immune=%10.6e\n",sex,sus[sex][0],incub[sex][0],infous[sex][0],immune[sex][0]);
  numsus_cb=births[sex]*exp(-equm_annfoi_y*(age_cb-0.5));
  for (age=1;age<=up_age;++age){
     if (age<=age_cb){
        sus[sex][age]=births[sex]*(exp(-equm_annfoi_y*(age-0.5)));
        new_infns=sus[sex][age]*equm_annfoi_y/(1.0*num_days);
     }
     else {
         sus[sex][age]=numsus_cb*(exp(-equm_annfoi_o*(age-age_cb)));
         new_infns=sus[sex][age]*equm_annfoi_o/(1.0*num_days);
     }
     infous[sex][age]=new_infns*infous_period_days;
     incub[sex][age]=new_infns*preinf_period_days;
     immune[sex][age]=births[sex]-sus[sex][age]-incub[sex][age]-infous[sex][age];
     sing_pop[sex][age]=sus[sex][age]+incub[sex][age]+infous[sex][age]+immune[sex][age];
     printf("age=%d sus=%10.6e incub=%10.6e infous=%10.6e immune=%10.6e\n",age,sus[sex][age],incub[sex][age],infous[sex][age],immune[sex][age]);
  }
}
printf("in new_initialize_popn\n");
}
 
