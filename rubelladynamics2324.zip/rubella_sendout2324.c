# include <stdio.h>
# include <math.h>
# include <stdlib.h>
# include <time.h>
# include <string.h>
# include <string>
# include <iostream>
#include <algorithm>

# define strngln 50
# define strgln_long 200
# define bsline_lngth 1500
# define vfile_lngth 65
# define ln_lngth 1500
# define vln_lngth 5000
# define dum_dpts 12
# define line_lngth 500
# define line_lngth 500

# define max(x,y)  (((x) > (y)) ? (x) : (y))
# define min(x,y)  (((x) < (y)) ? (x) : (y))

using namespace std;

double **dmatrix(int nrl, int nrh, int ncl, int nch);
double *dvector(int nl, int nh);
float **matrix(int nrl, int nrh, int ncl, int nch);
double ***d3tensor(int nrl, int nrh, int ncl, int nch, int ndl, int ndh);
void free_vector(float *v, int nl,int nh);
void free_dvector(double *v, int nl,int nh);
void free_dmatrix(double **m, int nrl, int nrh, int ncl, int nch);
void free_d3tensor(double ***t, int nrl, int nrh, int ncl, int nch,
              int ndl, int ndh);
double sumV( double *v, int start, int stop );   
double newmetricV( double *v, int start, int stop );  
int sum_include_yrage( int ***include_yrage, int yr_int, int min_year_vacc, int fin_year, int up_age );  
			  
void send_startdetails(char detailed_outfile[],char summary_outfile[],char imperial_outfile[],char time_now[]){
/* This sends output on the start time of the model runs to the output files  */

FILE *ofp_fin,*ofp,*ofp_imp;

  ofp = fopen(detailed_outfile,"a");
  fprintf(ofp,"\nCreated_on_%s\t",time_now);
  fclose(ofp);

  ofp_fin = fopen(summary_outfile,"a");
  fprintf(ofp_fin,"\nCreated_on_%s\t",time_now);
  fclose(ofp_fin);
  
  ofp_imp = fopen(imperial_outfile,"a");
  fprintf(ofp_imp,"\nCreated_on_%s\t",time_now);
  fclose(ofp_imp);
  
}

void send_details_to_files(char detailed_outfile[],char summary_outfile[],char imperial_outfile[],
                            int country_num,int country_code,char selcntry[],
                            char bs_sourcename[], char bs_avefile[], int scen_opt,int reqd_bsreplicate,
                                     float frac_import,
									 float pvacc_again,
									 double new_vacc_eff,
									 char brate_file[],char male_mrate_file[],char fem_mrate_file[],
									 char male_popfile[],char fem_popfile[],char life_expectancy_file[],									
									 char aspfert_file[],char sia_details_file[], char rcv1_cov_file[],
									 char rcv2_cov_file[], double crs_cfr, double scaleFactor, float risk_crs ){
  // Sends the parameter values for the current run to the output files 										 
										 
FILE *ofp_fin,*ofp,*ofp_imp;
									 
  ofp = fopen(detailed_outfile,"a");
  printf("entered send_details_to_files\n");
 
  printf("sia_details_file=%s\trcv1_cov_file=%s\trcv2_cov_file=%s\n",sia_details_file,rcv1_cov_file,rcv2_cov_file);

  fprintf(ofp,"country_num=%d\tcountry=%s\tcountry_code=%d\tbs_source_name=%s\tscen_opt=%d\t", 
               country_num,selcntry,country_code,bs_sourcename,scen_opt);
  fprintf(ofp,"brate_file=%s\tmale_mrate_file=%s\tfem_mrate_file=%s\tmale_popfile=%s\tfem_popfile=%s\tlife_expectancy_file=%s\t",
			   brate_file,male_mrate_file,fem_mrate_file,
									 male_popfile,fem_popfile,life_expectancy_file);
			   			   
  fprintf(ofp,"aspfert_file=%s\tsia_details_file=%s\trcv1_cov_file=%s\trcv2_cov_file=%s\t",
                 aspfert_file,
				 sia_details_file,rcv1_cov_file,rcv2_cov_file);
									 
  fprintf(ofp,"reqd_bsreplicate=%d\tfrac_import=%10.6e\tpvacc_again=%10.6e\tnew_vacc_eff=%10.6e\t",
                          reqd_bsreplicate,frac_import,pvacc_again,new_vacc_eff);				 
				 
  fclose(ofp);
  printf("done detailed\n");
  ofp_fin = fopen(summary_outfile,"a");
  ofp_imp=fopen(imperial_outfile,"a");

  fprintf(ofp_fin,"%d\t%s\t%d\t%s\t%s\t%d\t", // %d\t",
              country_num,selcntry,country_code,bs_sourcename, bs_avefile, scen_opt); 

  fprintf(ofp_fin,"%s\t%s\t%s\t%s\t%s\t%s\t",
  			   brate_file,male_mrate_file,fem_mrate_file,
									 male_popfile,fem_popfile,life_expectancy_file);
  
  fprintf(ofp_fin,"%s\t%s\t%s\t%s\t",
                    aspfert_file,sia_details_file,rcv1_cov_file,rcv2_cov_file);    

fprintf( ofp_fin, "%d\t%10.6e\t%10.6e\t%10.6e\t%10.6e\t%10.6e\t%f\t", 
                    reqd_bsreplicate,frac_import,  pvacc_again, new_vacc_eff, crs_cfr, scaleFactor, 
					risk_crs );  
  
  fprintf(ofp_imp,"%d\t%s\t%d\t%s\t%s\t%d\t", //%d\t",
                     country_num,selcntry,country_code,bs_sourcename, bs_avefile, 
                    scen_opt); 
					
  fprintf(ofp_imp,"%s\t%s\t%s\t%s\t%s\t%s\t",
  			   brate_file,male_mrate_file,fem_mrate_file,
									 male_popfile,fem_popfile,life_expectancy_file);

  fprintf(ofp_imp,"%s\t%s\t%s\t%s\t",					
					aspfert_file,
                    sia_details_file,rcv1_cov_file,rcv2_cov_file);    


  fprintf( ofp_imp, "%d\t%10.6e\t%10.6e\t%10.6e\t%10.6e\t%10.6e\t%f\t", reqd_bsreplicate,
					frac_import,  pvacc_again, new_vacc_eff, crs_cfr, scaleFactor, risk_crs );  
  fclose(ofp_fin);
  fclose(ofp_imp);
  
}
	

void send_imperial_output(char imperial_outfile[],int first_imp_yr,int fin_imp_yr,int up_age,
                          int low_impage_reqd,int high_impage_reqd,
                          int reqd_bsreplicate,int replicate_num,
						  char selcntry[],char country_abbrev[],
						  double crs_cfr,double daly_factor,
                          double ***obspop,
                          double **yr_asp_cases_actual,double **yr_asp_deaths_actual,double **yr_asp_dalys_actual,
                          double **yr_asp_infns_actual,
						  double **yr_asp_YLL_actual){
							  
// This sends out the output for the current run to an output file which is provided for VIMC  
							  
int age,year;
int age_crs_low = 15;
int age_crs_high = 49;
FILE *ofp;

string strselcntry(selcntry);
strselcntry.erase(std::remove(strselcntry.begin(), strselcntry.end(), '_'), strselcntry.end());
strselcntry.erase(std::remove(strselcntry.begin(), strselcntry.end(), ','), strselcntry.end());
	
ofp=fopen(imperial_outfile,"a");	
fprintf(ofp,"\n");
printf("entered send_imperial_output up_age=%d fin_imp_yr=%d\n",up_age,fin_imp_yr);
// exit(1);
if (reqd_bsreplicate>0) {
  for (year=first_imp_yr;year<=fin_imp_yr;++year)
    for (age=low_impage_reqd;age<=high_impage_reqd;++age){
	   if (( yr_asp_deaths_actual[year][age]<0) || (yr_asp_cases_actual[year][age]<0) || (yr_asp_infns_actual[year][age]<0) || (yr_asp_dalys_actual[year][age]<0)
              || (yr_asp_YLL_actual[year][age]<0 )  ){
	     fprintf(stderr,"Negative numbers of cases, infns, deaths, DALYS or YLL! country_abbrev=%s  deaths=%10.6e cases=%10.6 infns=%10.6e dalys=%10.6e YLL=%10.6e\n Exiting program...",
		                      country_abbrev,yr_asp_deaths_actual[year][age],
                                   yr_asp_cases_actual[year][age],
								   yr_asp_infns_actual[year][age], 
								   yr_asp_dalys_actual[year][age],
								   yr_asp_YLL_actual[year][age]);
	     printf("Negative numbers of cases, infns, deaths or DALYS! country_abbrev=%s  deaths=%10.6e cases=%10.6 infns=%10.6e dalys=%10.6e YLL=%10.6e\n Exiting program...",
		                      country_abbrev,yr_asp_deaths_actual[year][age],
                                   yr_asp_cases_actual[year][age],
								   yr_asp_infns_actual[year][age], 
								   yr_asp_dalys_actual[year][age],
								   yr_asp_YLL_actual[year][age]						   
								 );
		 exit(1);
	
	   }
	
        if ( (age < age_crs_low) || (age > age_crs_high) ) {
            fprintf(ofp,"%s,%d,%d,%d,%s,%s,%.0f,%s,%s,%s,%.2f,%s\n",
	                               "Rubella",replicate_num,year,age,
	                               country_abbrev,strselcntry.c_str(),
	                               obspop[0][year][age]+obspop[1][year][age],
								   "NA",
                                   "NA",
								   "NA",
								   yr_asp_infns_actual[year][age],
								   "NA");	
	   printf("%s\t%d\t%d\t%d\t%s\t%s\t%10.0f\t%s\t%s\t%s\t%10.2f\t%s\n",
	                               "Rubella",replicate_num,year,age,
	                               country_abbrev,strselcntry.c_str(),
	                               obspop[0][year][age]+obspop[1][year][age],
								   "NA",
                                   "NA",
								   "NA",
								   yr_asp_infns_actual[year][age],
								   "NA");	
        }
        else {
	   fprintf(ofp,"%s,%d,%d,%d,%s,%s,%.0f,%.2f,%.2f,%.2f,%.2f,%.2f\n",
	                               "Rubella",replicate_num,year,age,
	                               country_abbrev,strselcntry.c_str(),
	                               obspop[0][year][age]+obspop[1][year][age],
								   yr_asp_dalys_actual[year][age],
                                   yr_asp_cases_actual[year][age],
								   yr_asp_deaths_actual[year][age],
								   yr_asp_infns_actual[year][age],
								   yr_asp_YLL_actual[year][age]);
								   
	   printf("%s\t%d\t%d\t%d\t%s\t%s\t%10.0f\t%10.2f\t%10.2f\t%10.2f\t%10.2f\t%10.2f\n",
	                               "Rubella",replicate_num,year,age,
	                               country_abbrev,strselcntry.c_str(),
	                               obspop[0][year][age]+obspop[1][year][age],
								   yr_asp_dalys_actual[year][age],
                                   yr_asp_cases_actual[year][age],
								   yr_asp_deaths_actual[year][age],
								   yr_asp_infns_actual[year][age],
								   yr_asp_YLL_actual[year][age]);									   
        }
    }								   
}
else{
  for (year=first_imp_yr;year<=fin_imp_yr;++year){
//	printf("year=%d\n",year);
    for (age=low_impage_reqd;age<=high_impage_reqd;++age){
        if ( (age < age_crs_low) || (age > age_crs_high) ) {
            fprintf(ofp,"%s,%d,%d,%s,%s,%.0f,%s,%s,%s,%.2f,%s\n",
	                               "Rubella",year,age,
	                               country_abbrev,strselcntry.c_str(),
	                               obspop[0][year][age]+obspop[1][year][age],
								   "NA",
                                   "NA",
								   "NA",
								   yr_asp_infns_actual[year][age],"NA");	
	   printf("%s,%d,%d,%s,%s,%10.0f,%s,%s,%s,%10.2f,%s\n",
	                               "Rubella",year,age,
	                               country_abbrev,strselcntry.c_str(),
	                               obspop[0][year][age]+obspop[1][year][age],
								   "NA",
                                   "NA",
								   "NA",
								   yr_asp_infns_actual[year][age],
								   "NA");	
        }
        else {
	   fprintf(ofp,"%s,%d,%d,%s,%s,%.0f,%.2f,%.2f,%.2f,%.2f,%.2f\n",
	                               "Rubella",year,age,
	                               country_abbrev,strselcntry.c_str(),
	                               obspop[0][year][age]+obspop[1][year][age],
								   yr_asp_dalys_actual[year][age],
                                   yr_asp_cases_actual[year][age],
								   yr_asp_deaths_actual[year][age],
								   yr_asp_infns_actual[year][age],
								   yr_asp_YLL_actual[year][age]);	
	   printf("%s,%d,%d,%s,%s,%10.0f,%10.2f,%10.2f,%10.2f,%10.2f,%10.2f\n",
	                               "Rubella",year,age,
	                               country_abbrev,strselcntry.c_str(),
	                               obspop[0][year][age]+obspop[1][year][age],
								   yr_asp_dalys_actual[year][age],
                                   yr_asp_cases_actual[year][age],
								   yr_asp_deaths_actual[year][age],
								   yr_asp_infns_actual[year][age],
								   yr_asp_YLL_actual[year][age]);	
        }
	}	
  }	
}
printf("finished here");
fclose(ofp); 
}

				   
void send_CRS_incidence(char detailed_outfile[],char summary_outfile[],char imperial_outfile[],
                    int reqd_bsreplicate,int replicate_num,
                    int step_freq,int yr_start_store,int country_num, char selcntry[],char country_abbrev[],
					int tot_days,
                    double total_vacc[],
					double ****asp_num_actual_crs,
					double ***wgt_num_actual_crs,double ***wgt_store_crs_phklb_mid,
                    double **asp_num_actual_infns_pday,
					double **age_stndis_actual_infns_pday,
					int start_gavi,int fin_gavi,int fin_year,
					int first_imp_yr,int fin_imp_yr,
					double crs_cfr, double daly_factor,
					double life_expectancy_at_birth[],					
					int up_age, 
					double ***obspop,
                    int low_impage_reqd,int high_impage_reqd){  // Kostas 19-02-2016

/* This function takes the output generated for each time step and aggregates it to produce the yearly output. 
   The yearly and age-specific output is sent to  imperial_outfile, which has the output required by VIMC. 
   Selected yearly output (aggregated across all age groups) is sent to the summary_outfile, which can be used for checking that the output makes sense
   Output is also sent to the detailed_outfile; however, this is not used and has been kept in for historical reasons  */

				   
int v_ind,beta_num,dd,step,num_steps,age;
int rem_quart;
int yr_for_stndisn;
double yr_step;
double cum_num_actual,step_num_actual;
double *asp_step_num_actual=dvector(0,up_age);
double *asp_step_num_infns=dvector(0,up_age);
double *astd_step_num_infns=dvector(0,up_age);
div_t calc_quart;
FILE *ofp,*ofp_fin;
double **yr_asp_infns_actual    = dmatrix( start_gavi, fin_gavi,0,up_age);
double **yr_asp_cases_actual    = dmatrix( start_gavi, fin_gavi,0,up_age);           
double *yr_CRS_cases_phklbths = dvector( start_gavi, fin_gavi);			
double **yr_asp_deaths_actual     = dmatrix( start_gavi, fin_gavi,0,up_age); 
double **yr_asp_dalys_actual     = dmatrix( start_gavi, fin_gavi,0,up_age);  
double **yr_asp_YLL_actual     = dmatrix( start_gavi, fin_gavi,0,up_age);    

double *yr_total_infns_actual     = dvector( start_gavi, fin_gavi);      
double *yr_age_stndized_infn_incid = dvector( start_gavi, fin_gavi);     
double yr_age_stndized_num_infns,total_pop_stndisn_yr;
double age_obspop,*yr_total_obspop = dvector( start_gavi, fin_gavi);     
double *yr_total_dalys = dvector( start_gavi, fin_gavi);                 

int year;

for (year=start_gavi;year<=fin_gavi;++year){
    yr_total_infns_actual[year]=0.0;
	yr_total_obspop[year]=0.0;
	yr_age_stndized_infn_incid[year]=0.0;
	yr_total_dalys[year]=0.0;	
	for (age=0;age<=up_age;++age){
		yr_asp_cases_actual[year][age]=yr_asp_deaths_actual[year][age]=0.0;
	    yr_asp_dalys_actual[year][age]=yr_asp_YLL_actual[year][age]=0.0;	
	}
}	

yr_for_stndisn=2000;
total_pop_stndisn_yr=0.0;
for (age=0;age<=up_age;++age){
   asp_step_num_actual[age]=asp_step_num_infns[age]=astd_step_num_infns[age]=0.0;
   total_pop_stndisn_yr+= obspop[0][yr_for_stndisn][age]+ obspop[1][yr_for_stndisn][age];
 }  
	
ofp = fopen(detailed_outfile,"a");
ofp_fin = fopen(summary_outfile,"a");  


v_ind=0;
num_steps= tot_days/step_freq;
step=0;yr_step=yr_start_store*1.0;
cum_num_actual=step_num_actual=0.0;
printf("entered send_CRS_incidence\n");

/*
printf("\n\nOutput on the CRS incidence for %s at intervals of %d days\n",selcntry,step_freq);
printf("days_since_%d\tyear\tQuarterly_number_CRS_cases\tcum_num_CRS_cases_since_%d\tCRS_incid_pHK_lbths\n",yr_start_store,yr_start_store);

fprintf(ofp,"\n\nOutput on the CRS incidence for %s at intervals of %d days\n",selcntry,step_freq);
fprintf(ofp,"days_since_%d\tyear\tQuarterly_number_CRS_cases\tcum_num_CRS_cases_since_%d\tCRS_incid_pHK_lbths\n",yr_start_store,yr_start_store);
*/

fprintf(ofp_fin,"Numbers_of_individuals_vaccinated_in_each_year_during_%d_to_%d:\t",start_gavi,fin_year-1);
for (year=start_gavi;year<fin_year;++year) fprintf(ofp_fin,"%10.6e\t",total_vacc[year]);

if (step_freq==365) fprintf( ofp_fin,"Annual_number_of_CRS_cases,_%d-%d_(population-level):\t",yr_start_store,fin_gavi-1);    // EV 16.11.17

for (dd=0;dd<tot_days;++dd){    
  calc_quart=div(dd,step_freq);
  rem_quart=calc_quart.rem;
  for (beta_num=1;beta_num<=1;++beta_num){   // when have additional beta_nums, should index cum_num_actual and step_num_actual by beta_num
    cum_num_actual+=wgt_num_actual_crs[beta_num][v_ind][dd];
	step_num_actual+=wgt_num_actual_crs[beta_num][v_ind][dd];
	for (age=0;age<=up_age;++age) {
        asp_step_num_actual[age]+=asp_num_actual_crs[beta_num][v_ind][age][dd];
        asp_step_num_infns[age]+=asp_num_actual_infns_pday[age][dd];
		astd_step_num_infns[age]+=age_stndis_actual_infns_pday[age][dd];		
    }
	
	if ( ( rem_quart == 0 ) && ( dd > 0 ) ){  
       printf("%d\t%10.6e\t%10.6e\t%10.6e\t%10.6e\n",dd,yr_step,step_num_actual,cum_num_actual,wgt_store_crs_phklb_mid[beta_num][v_ind][dd]);
	//    fprintf(ofp,"%d\t%10.6e\t%10.6e\t%10.6e\t%10.6e\n",dd,yr_step,step_num_actual,cum_num_actual,wgt_store_crs_phklb_mid[beta_num][v_ind][dd]); 
	   if (step_freq==365){     
		if (step_num_actual<0) {
		  fprintf(ofp_fin,"Negative numbers of cases...exiting program\n");
		  exit(1);
		}
		fprintf(ofp_fin,"%10.6e\t",step_num_actual);
		yr_CRS_cases_phklbths[(int)yr_step ]= wgt_store_crs_phklb_mid[beta_num][v_ind][dd];	

		yr_total_infns_actual[(int)yr_step ] =0.0;
		yr_total_obspop[(int)yr_step ]=0.0;
		yr_total_dalys[(int)yr_step ]=0.0;
		yr_age_stndized_num_infns=0.0;
		printf("yr_step=%10.6e\n",yr_step);
		for (age=0;age<=up_age;++age){
		    age_obspop=obspop[0][int(yr_step)][age]+ obspop[1][int(yr_step)][age];
			yr_asp_cases_actual[ (int)yr_step ][age] = asp_step_num_actual[age];
            yr_asp_infns_actual[ (int)yr_step ][age] = asp_step_num_infns[age];  
			yr_asp_deaths_actual[ (int)yr_step ][age] = asp_step_num_actual[age]*crs_cfr;		
			yr_asp_dalys_actual[ (int)yr_step ][age] = asp_step_num_actual[age]*daly_factor;	
            yr_asp_YLL_actual[ (int)yr_step ][age]  = 
			     asp_step_num_actual[age]*crs_cfr*life_expectancy_at_birth[(int)yr_step];	

			yr_total_infns_actual[(int)yr_step ] += asp_step_num_infns[age];
			yr_total_obspop[(int)yr_step ] += age_obspop;			
			yr_total_dalys[(int)yr_step ] +=yr_asp_dalys_actual[ (int)yr_step ][age];
			
			yr_age_stndized_num_infns +=astd_step_num_infns[age]; 
		
		} 
		yr_age_stndized_infn_incid[(int)yr_step ]= 1e5*yr_age_stndized_num_infns/total_pop_stndisn_yr;
		
     }  
	   
	   step_num_actual=0.0;
	   for (age=0;age<=up_age;++age) {
           asp_step_num_actual[age]=asp_step_num_infns[age]=astd_step_num_infns[age]=0.0;
       }
	   ++step;
    }
    yr_step+=1/365.0;
  }
}  
printf("post asp_step_num_actual\n");
free_dvector(asp_step_num_actual,0,up_age);
free_dvector(asp_step_num_infns,0,up_age);
printf("freed asp_step_num_actual\n");

fprintf( ofp_fin,"Annual_number_of_infns,_%d-%d_(population_level):\t",yr_start_store,fin_gavi-1);   
for (year=yr_start_store;year<fin_gavi;++year){
  if (yr_total_infns_actual[year]<0) {
	 fprintf(ofp_fin,"Negative numbers of infns...exiting program\n");
	  exit(1);
  }
  fprintf(ofp_fin,"%10.6e\t",yr_total_infns_actual[year]);
}  
  
  
fprintf( ofp_fin,"Annual_population_size,_%d-%d:\t",yr_start_store,fin_gavi-1);   
for (year=yr_start_store;year<fin_gavi;++year)
  fprintf(ofp_fin,"%10.6e\t",yr_total_obspop[year]);

fprintf( ofp_fin,"Age-standardised_numinfns_pHK,_%d-%d:\t",yr_start_store,fin_gavi-1);   
for (year=yr_start_store;year<fin_gavi;++year)
  fprintf(ofp_fin,"%10.6e\t",yr_age_stndized_infn_incid[year]);


fprintf( ofp_fin,"Total_DALYs,_%d-%d:\t",yr_start_store,fin_gavi-1);    
for (year=yr_start_store;year<fin_gavi;++year)
  fprintf(ofp_fin,"%10.6e\t",yr_total_dalys[year]);

fprintf( ofp_fin,"CRS_cases_perHK_livebirths,_%d-%d:\t",yr_start_store,fin_gavi-1);    
for (year=yr_start_store;year<fin_gavi;++year)									
  fprintf(ofp_fin,"%10.6e\t", yr_CRS_cases_phklbths[year]);						

fclose(ofp_fin);

printf("pre finished sending output to ofp_fin\n");

free_dvector(yr_CRS_cases_phklbths,start_gavi, fin_gavi);						

printf("freed yr_CRS_cases_phklbths\n");


free_dvector(yr_total_infns_actual,start_gavi,fin_gavi);

printf("pre send_imperial_output\n");

send_imperial_output(imperial_outfile,first_imp_yr,fin_imp_yr,up_age,
                          low_impage_reqd,high_impage_reqd,
                          reqd_bsreplicate,replicate_num,
						  selcntry,country_abbrev,
						  crs_cfr,daly_factor,
                          obspop,
                          yr_asp_cases_actual,yr_asp_deaths_actual,yr_asp_dalys_actual, 
						  yr_asp_infns_actual,
						  yr_asp_YLL_actual);

printf("completed send_imperial output\n");


fclose(ofp);
fclose(ofp_fin);
}

