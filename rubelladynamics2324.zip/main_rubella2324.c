/*   Rubella model code used for VIMC runs, 2023-4
     Authors: Emilia Vynnycky with contributions from Timos Papadopoulos, Kostas Angelis over the preceding 10+ years 

     The model relies on code in the following files:
	 
	main_rubella2324.c
	rubella_readin2324.c
	rubella_tdynamics2324.c
	rubella_sendout2324.c
    unrutil.c 	

	 
	 The code in the main file is structured as follows:
	 1. The "main()" section reads in the required inputs from the command line (country number, first repetition number, 
	 last repetition number, vaccine scenario number, names of demographic and vaccination input files
	 2. After the inputs have been read in, it calls up the function "loop_over_reps()".
	    For the country specified by the country number, loop_over_reps() does the following:
		a) For each of the replicates between first_replicate and maximum possible replicate (200), It also 
		assigns values for the CRS-related case-fatality rate, risk of a child being born with CRS following infection 
		in the mother during the first 16 weeks of pregnancy, vaccine efficacy and the bootstrap_number (which determines the value used 
		for the force of infection). These are are drawn from the files dis.mort, 
		risk.crs, vacc.eff and bootstrap.   

		b) It reads in the appropriate demographic values from 
		the corresponding demography input files and assigns them to the corresponding variable. 
		
		c) For each of the replicates, it assigns an output file name and sends the parameter values used for the current run to the file, before 
		calling up the function reduced_readin_rubella_dynamics(), which carries out the dynamic model runs generating the output required for VIMC.
	3. reduced_readin_rubella_dynamics() has the following general structure:
	   a) Extract the equilibrium pre-vaccination force of infection from input files and calculate the parameters later used by the model 
	      for calculating the force of infection over time.
	   b) Extract the vaccination coverage 
	   c) Initialise the contact parameters, compartmente and other output variables
	   d) Loop over time to calculate various outputs of interest in each time step and store the outputs of interest
	   e) Once the loop over time has finished, the function calls up send_CRS incidence(), which sends the output to various output files
	 
*/

# include <stdio.h>
# include <math.h>
# include <stdlib.h>
# include <time.h>
# include <string.h>

# define strngln 100 
# define vfile_lngth 65
# define ln_lngth 1500
# define dum_dpts 12
# define line_lngth 500
# define min_year_vacc 1980  
# define max_year_vacc 2100  

# define max(x,y)  (((x) > (y)) ? (x) : (y))
# define min(x,y)  (((x) < (y)) ? (x) : (y))

int **imatrix(int nrl, int nrh, int ncl, int nch);
int ***i3tensor(int nrl, int nrh, int ncl, int nch, int ndl, int ndh);
double **dmatrix(int nrl, int nrh, int ncl, int nch);
float *vector(int nl, int nh);
int *ivector(int nl,int nh);
double *dvector(int nl, int nh);
float **matrix(int nrl, int nrh, int ncl, int nch);
double ***d3tensor(int nrl, int nrh, int ncl, int nch, int ndl, int ndh);
double ****d4tensor(int nrl, int nrh, int ncl, int nch, int ndl, int ndh, int nal, int nah);
void free_vector(float *v, int nl,int nh);
void free_ivector(int *v, int nl,int nh);
void free_dvector(double *v, int nl,int nh);
void free_imatrix(int **m, int nrl, int nrh, int ncl, int nch);
void free_dmatrix(double **m, int nrl, int nrh, int ncl, int nch);
void free_i3tensor(int ***t, int nrl, int nrh, int ncl, int nch,
              int ndl, int ndh);
void free_d3tensor(double ***t, int nrl, int nrh, int ncl, int nch,
              int ndl, int ndh);
void free_d4tensor(double ****t, int nrl, int nrh, int ncl, int nch, int ndl, int ndh, int nal, int nah);


char sumfile[strngln];

void get_para(char infile[],double para[],int max_rep);

void loop_over_reps(int first_rep,int final_rep,
                  int scen_opt,
                  int country_num,int fin_year,
                  char details_bratefile[],char details_male_mratefile[],
					char details_fem_mratefile[],
                   char details_male_popfile[],char details_fem_popfile[],
				   char details_lexpfile[],
                   char details_aspfertfile[],
				   char siaFile[],
					char details_rcv1File[], char details_rcv2File[], char bs_sourcefile[],
					float pvacc_again, float frac_import);

void reduced_readin_rubella_dynamics(char summary_outfile[],char detailed_outfile[],
                   char imperial_outfile[],
				   int country_num,int country_code,char selcntry[],char country_abbrev[],
				   int fin_year,
                   int scen_opt,double new_vacc_eff, 
					int replicate_num, int reqd_bsreplicate, 
                   char aspfert_file[],							
				   char sia_details_file[],
				   char rcv1_cov_file[],char rcv2_cov_file[],
					char bs_sourcename[],char bs_avefile[],
					double crs_cfr, double scaleFactor, float risk_crs, 
					float pvacc_again, float frac_import,
					double ***obs_pop,double life_expectancy_at_birth[],
					double **m_rate,float *ann_brate,
					int start_sim,int reqd_demog_year,
					int min_age,int up_age,double daly_factor);

									 
void get_bscountrycode_abbrev2017(int country_num,int *country_code,char selcntry[],char country_abbrev[], 
                                  double *daly_factor,char bs_sourcefile[],
                                     char bs_sourcename[], char bs_avefile[]);									 
void get_imppopdata(char popfile[],double **obs_pop,int country_code,int min_year,int max_year,
                 int min_age,int maxage);

void get_imp_brate_2017(char brate_file[],int country_code,float ann_brate[],int start_sim,int fin_year,int reqd_demog_year);

void get_imp_mrate(char alivefile[],double m_rate[],int country_code,int min_age,int maxage,int reqd_demog_year);

void get_implife_expectancy(char life_expectancy_file[],
                 double life_expectancy_at_birth[],
                 int country_code,int min_year,int max_year);

void get_impaspfert(char aspfert_file[],double **yr_imp_aspfert,int country_code,
                    int up_age,int min_year,int fin_year,int max_agefert);					  


void setup_propage(int num_days,int num_tsteps_pyr,int tsteps_pday,float tstep_size,int start_sim,int fin_year,int up_age,double prop_age[],
                 double **m_rate,float ann_brate[]);
void get_prop_mat_and_y(double *prop_mat,double *prop_y,double *prop_age,int age_cb,int up_age);

void get_bstraps_and_betas_sing_2015(int age_cb,int up_age,double foi_ptsus_y[],double foi_ptsus_o[],double **equm_ann_foi,double **beta_vals,
                             double prop_age[],double infous_period_days,double total_popn_start,double k_val[],
                             int reqd_bsreplicate, char use_bsfile[], char sumfile[]);

void update_compartments(int sex,int age,int year,int day,int tstep_in_year,int durn_mat_tsteps,
               double **sus,double **incub,double **infous,double **immune,double *lambda,			   
			   double **sing_inf_pyr,double **sing_inf_pday,
               double **m_rate,float tstep_size,double infous_rate_pday,double rec_rate_pday,
			   double *effvacc_18mths);
							 
void update_fyol_compartments(int sex,int year,int day,int tstep_in_year,int durn_mat_tsteps,int durn_9mths_tsteps,
               double mat[],double **sus,double **incub,double **infous,double **immune,double *lambda,			   
			   double **sing_inf_pyr,double **sing_inf_pday,
               double **m_rate,float tstep_size,double infous_rate_pday,double rec_rate_pday,
			   double *effvacc_mat,double *effvacc_9mths);							 
							 
void imp_assign_include_sia_and_vaccn(char sumfile[], char sia_details_file[], char rcv1_cov_file[], 
				char rcv2_cov_file[], int intended_c_num, int intended_c_code, 
				double **agesp_scov_mat,double **agesp_scov_9mths,double ***agesp_scov,double **rcv_cov_9mths,double ***rcv_cov_dose2,
				int min_year, int max_year, int fin_gavi, int min_age, 
				int maxage, 
				double scaleFactor );
				 
void send_details_to_files(char detailed_outfile[],char summary_outfile[],char imperial_outfile[],
                       int country_num,int country_code,char selcntry[],
                                     char bs_sourcename[], char bs_avefile[], int scen_opt,
									 int reqd_bsreplicate,
                                     float frac_import,
									 float pvacc_again,
									 double new_vacc_eff,
									 char brate_file[],char male_mrate_file[],char fem_mrate_file[],
									 char male_popfile[],char fem_popfile[],char life_expectancy_file[],									
									 char aspfert_file[],char sia_details_file[], char rcv1_cov_file[],
									 char rcv2_cov_file[], double crs_cfr, double scaleFactor, float risk_crs );	
							 
void get_applied_effcov(int year,int m_year_vacc,double effvacc_mat[],double effvacc_9mths[],double **effvacc_cov,
                      double **agesp_scov_mat,double **agesp_scov_9mths,double ***agesp_scov,double **rcv_cov_9mths,double ***rcv_cov_dose2,
					  double vacc_eff,int up_age);							 

void get_applied_suscov(int year,int m_year_vacc,double **effvacc_sus,
                     double ***agesp_scov,double **rcv_cov_9mths,
					  double ***rcv_cov_dose2,double vacc_eff,int up_age,float pvacc_again);
					  
void new_define_outcats(int **age_out,int num_outcats,int crs_cat[],int max_crs_ind);
				
void send_CRS_incidence(char detailed_outfile[],char summary_outfile[],char imperial_outfile[],
                    int reqd_bsreplicate,int replicate_num,
                    int step_freq,int yr_start_store,int country_num, char selcntry[],char country_abbrev[],
					int tot_days,double total_vacc[],
					double ****asp_num_actual_crs,
					double ***wgt_num_actual_crs,double ***wgt_store_crs_phklb_mid,
                    double **asp_num_actual_infns_pday,
					double **age_stndis_actual_infns_pday,
					int start_gavi,int fin_gavi,int fin_year,
					int first_imp_yr,int fin_imp_yr,
					double crs_cfr, double daly_factor,
					double life_expectancy_at_birth[],					
					int up_age, double ***obspop,
                    int low_impage_reqd,int high_impage_reqd);

void introduce_importations(int maxage,double *sus,double *infous, float frac_import);
				   
void growing_calc_foi(int age_cb,double *lambda,double **ecr,double **infous,double **sing_pop,double mat[],int up_age);


void new_initialize_popn(int up_age,int age_cb,double *equm_annfoi,double preinf_period_days,double infous_period_days,
              int num_days,
              double *births,double *mat,double **sus,double **incub,double **infous,double **immune,double **sing_pop);

void nounvacc_vacc_store_brate_new_end_of_year(double **sus,double **incub,double **infous,double **immune,double *lambda,
                 double **effvacc_sus,
                 double mat[],double effvacc_mat[],double **sing_inf_pday,double **sing_inf_pyr,double **m_rate,
                  int up_age,double infous_rate_pday,double rec_rate_pday,float tstep_size, 
                 int year,float ann_brate,double **sing_pop);			  

void send_startdetails(char detailed_outfile[],char summary_outfile[],char imperial_outfile[],char time_now[]);				   
				   
		 				  
int
main(int argc, char *argv[]){
  int country_num, fin_year, scen_opt; 
  int reqd_bsreplicate, replicate_num;        
  int first_rep,final_rep;
  
  double new_vacc_eff;

  char detailed_outfile[strngln],summary_outfile[strngln],imperial_outfile[strngln];
  char details_bratefile[strngln],details_male_mratefile[strngln],details_fem_mratefile[strngln];
  char details_male_popfile[strngln],details_fem_popfile[strngln],details_lexpfile[strngln];
  char details_aspfertfile[strngln];

  char siaFile[strngln];           
  char details_rcv1File[strngln],details_rcv2File[strngln];   
  char bs_sourcefile[strngln];     
  
  double crs_cfr;          
  double VaccEff;           // Vaccine efficacy imported from command line
  double scaleFactor;       // Scale factor to rescale vaccine coverage (imported from command line)
  float risk_crs;			
  float pvacc_again, frac_import;		
  time_t now;
FILE *ofp1;
 
  
  if ( argc != 19){  
   fprintf(stderr,"\n\nUnfortunately, you have supplied wrong command line arguments :(. \n");
   fprintf(stderr,"You need to supply 18 on the same line that you call this program...\n");
   fprintf(stderr,"These are: country_num fin_year scenario (not_used-integer_value_OK) \n");
   fprintf(stderr,"first_rep last_rep (0..1000)\n");
   fprintf(stderr,"name_of_SIA_file name_of_RCV1_file name_of_RCV2_file \n");
   fprintf(stderr,"name_of_bs_source_file \n");
   fprintf(stderr,"pvacc_again frac_import\n");
   fprintf(stderr,"Birth_rate_file  Male_survival_file  Female_survival_file\n");
   fprintf(stderr,"Male_population_file  Female_population_file  Life_expectancy_at_birth_file\n");
   fprintf(stderr,"Age-specific_fertility_rate_file \n exiting program...  \n");   
   exit(-1);
}

  country_num      = atoi(argv[1]);
  fin_year         = atoi(argv[2]);
    
  scen_opt         = atoi(argv[3]);
  printf("scen_opt=%d\n",scen_opt);

first_rep=atoi(argv[4]);
final_rep=atoi(argv[5]);
 
  strcpy( siaFile, argv[6] );                        
  
  printf("siaFile=%s\n",siaFile);
  
  strcpy( details_rcv1File, argv[7] );                                          
  printf("details_rcv1File=%s\n",details_rcv1File);  
  
    strcpy( details_rcv2File, argv[8] );                                
  printf("details_rcv2File=%s\n",details_rcv2File);    
    
  strcpy( bs_sourcefile, argv[9] );                                     

 
  sscanf( argv[10], "%f",  &pvacc_again);									
  sscanf( argv[11], "%f",  &frac_import);									

  strcpy( details_bratefile, argv[12] );                                
  printf("details_bratefile=%s\n",details_bratefile);    

  strcpy( details_male_mratefile, argv[13] );                                
  printf("details_male_mratefile=%s\n",details_male_mratefile);    

  strcpy( details_fem_mratefile, argv[14] );                                
  printf("details_fem_mrateFile=%s\n",details_fem_mratefile);    

  strcpy( details_male_popfile, argv[15] );                                
  printf("details_male_popFile=%s\n",details_male_popfile);    

  strcpy( details_fem_popfile, argv[16] );                                
  printf("details_fem_popfile=%s\n",details_fem_popfile);    

  strcpy( details_lexpfile, argv[17] );                                
  printf("details_lexpfile=%s\n",details_lexpfile);    

  strcpy( details_aspfertfile, argv[18] );                                
  printf("details_aspertfile=%s\n",details_aspfertfile);    


  printf("country_num=%d fin_year=%d scen_opt=%d\n",
               country_num,fin_year,scen_opt); 

if (fin_year<2000){
   fprintf(stderr,"Exiting program...last year for which output is provided must be after 2000\n");
   exit(1);
}
  

  loop_over_reps(first_rep,final_rep,
                  scen_opt,
                  country_num,fin_year,
                  details_bratefile,details_male_mratefile,
				  details_fem_mratefile,
                  details_male_popfile,details_fem_popfile,
				    details_lexpfile,
                    details_aspfertfile,
				    siaFile,
					details_rcv1File, details_rcv2File, bs_sourcefile,
					pvacc_again, frac_import);
}



void loop_over_reps(int first_rep,int final_rep,
                  int scen_opt,
                  int country_num,int fin_year,
                  char details_bratefile[],char details_male_mratefile[],
					char details_fem_mratefile[],
                   char details_male_popfile[],char details_fem_popfile[],
				   char details_lexpfile[],
                   char details_aspfertfile[],
				   char siaFile[],				 
					char details_rcv1File[], char details_rcv2File[], char bs_sourcefile[],
					float pvacc_again, float frac_import){

  double crs_cfr;          
  double new_vacc_eff;           // Vaccine efficacy imported from command line
  double scaleFactor;       // Scale factor to rescale vaccine coverage (imported from command line)
  float risk_crs;			
			
double *bs_num,*crs_mort,*crs_risk,*sfactor,*veff;
			
double ***obs_pop;
double *life_expectancy_at_birth;
double **m_rate;
float *ann_brate;
int age,sex,year;
int min_age,up_age;
int country_code,reqd_bsreplicate;
int rep,replicate_num;
int max_rep;
int start_sim,reqd_demog_year;

char bsfile[strngln],crsmortfile[strngln];
char crsriskfile[strngln],sffile[strngln],vefile[strngln];

char brate_file[strngln];
char male_mrate_file[strngln],fem_mrate_file[strngln];
char male_popfile[strngln], fem_popfile[strngln]; 
char life_expectancy_file[strngln];
char aspfert_file[strngln];

char rcv1_cov_file[strngln],rcv2_cov_file[strngln];
char sia_details_file[strngln];

  char detailed_outfile[strngln],summary_outfile[strngln],imperial_outfile[strngln];
  char extString[30];
  
    char s_out1[100],s_out2[100],s_out3[22]; 
	  time_t now;

char selcntry[40],country_abbrev[6],bs_sourcename[strngln];
char bs_avefile[ strngln ];
double daly_factor;

min_age=0;
up_age=99;   // Maximum age of individuals in model; 
max_rep=200;  // Maximum number of repetitions. This could up to 1000 if necessary, as it's determined by the number of  
               //  lines in the files dis.mort, risk.crs, vacc.eff and bootstrap.   

reqd_demog_year=2010;     // This determines the year for which the birth rate and age and sex-specific mortality rate is used
start_sim=1800;           // This is the starting year for the model runs. 


/****************************************************************************************************/   
/* Initialise and assign values for the bootstrap_number (used to specify the force of infection), CRS-related mortality, risk of a child being born with CRS, given 
   rubella infection in the mother infection and vaccine efficacy for each repetition between 0 and max_rep=200 */
/****************************************************************************************************/      

bs_num=dvector(0,max_rep);
crs_mort=dvector(0,max_rep);
crs_risk=dvector(0,max_rep);
sfactor=dvector(0,max_rep);
veff=dvector(0,max_rep);

bs_num[0]=0;
crs_mort[0]=0.3;
crs_risk[0]=0.65;
sfactor[0]=1.0;
veff[0]=0.95;

strcpy(bsfile,"inputfiles/bootstrap\0"); 
strcpy(crsmortfile,"inputfiles/dis.mort\0"); 
strcpy(crsriskfile,"inputfiles/risk.crs\0"); 
strcpy(sffile,"inputfiles/scale.factor\0"); 
strcpy(vefile,"inputfiles/vacc.eff\0"); 

// get_para() gets all the possible values for the parameter of interest that's varied 
get_para(bsfile,bs_num,max_rep);                 
get_para(crsmortfile,crs_mort,max_rep);
get_para(crsriskfile,crs_risk,max_rep);
// get_para(sffile,sfactor,max_rep); 
get_para(vefile,veff,max_rep);  

 for (rep=0;rep<=max_rep;++rep) sfactor[rep]=1.0;

 for (rep=0;rep<=max_rep;++rep)
	 printf("rep=%d bs_num=%10.6e crs_mort=%10.6e crs_risk=%10.6e sfactor=%10.6e veff=%10.6e\n",
                 rep,bs_num[rep],crs_mort[rep],crs_risk[rep],sfactor[rep],veff[rep]);
   
/****************************************************************************************************/         
/*  End of the section for initialising and assigning values for the bootstrap_number etc  */
/****************************************************************************************************/   
   
   
/****************************************************************************************************/      
/* Set up string variables holding the names of the demographic and vaccination coverage input files by adding the name of the folder where the demographic 
   variables can be found and the name of demographic input files, as read in earlier */
/****************************************************************************************************/         
   
strcpy( aspfert_file,"inputfiles/\0");
strcat(aspfert_file,details_aspfertfile);
printf("aspfert_file=%s\n",aspfert_file);

strcpy( brate_file,"inputfiles/\0");
strcat( brate_file,details_bratefile);
printf("brate_file=%s\n",brate_file);

strcpy( male_mrate_file,"inputfiles/\0");
strcat( male_mrate_file,details_male_mratefile);
printf("male_mrate_file=%s\n",male_mrate_file);

strcpy( fem_mrate_file,"inputfiles/\0");
strcat( fem_mrate_file,details_fem_mratefile);
printf("fem_mrate_file=%s\n",fem_mrate_file);

strcpy( male_popfile,"inputfiles/\0");
strcat( male_popfile,details_male_popfile);
printf("male_popfile=%s\n",male_popfile);

strcpy(fem_popfile,"inputfiles/\0");
strcat( fem_popfile,details_fem_popfile);
printf("fem_popfile=%s\n",fem_popfile);

strcpy(life_expectancy_file,"inputfiles/\0");
strcat( life_expectancy_file,details_lexpfile);
printf("life_expectancy_file=%s\n",life_expectancy_file);

strcpy( sia_details_file,"inputfiles/\0");
strcat( sia_details_file, siaFile );


strcpy( rcv1_cov_file,"inputfiles/\0");
strcat( rcv1_cov_file, details_rcv1File);

strcpy( rcv2_cov_file,"inputfiles/\0");
strcat( rcv2_cov_file, details_rcv2File);

printf("rcv1_cov_file=%s  rcv2_cov_file=%s",rcv1_cov_file,rcv2_cov_file);

/****************************************************************************************************/      
/* End of the section setting up string variables holding the names of the demographic and vaccination input files
/****************************************************************************************************/      


/****************************************************************************************************/      
/* Initialise variables storing several of the demographic paramaters (observed population, age and sex-specific mortality rate,
   life expectancy, birth rate), read in and assign their values from the input files specific above for the country specified 
   by country_num.  To ensure that the values for the appropriate country are read in, the code finds the UN 
   country_code for the given country by reading in its value from bsdalcc2024.inp in the function get_bscountrycode_abbrev2017().
   Whilst it's in this function, it also reads in the name of the files holding the force of infection for the country, as well as
   the daly.  The fertility rate and vaccination coverage is assigned in a different section of the code.
   
/****************************************************************************************************/      

obs_pop=d3tensor(0,1,min_year_vacc,fin_year,0,up_age);    // Observed population.  obs_pop[0][y][a] = number of males in year y or age a; 
                                                          //  obs_pop[1][y][a] = number of females in year y or age a; 
life_expectancy_at_birth=dvector(min_year_vacc,fin_year);

for (year=min_year_vacc;year<=fin_year;++year){
  life_expectancy_at_birth[year]=0.0;
  for (sex=0;sex<=1;++sex)
    for (age=0;age<=up_age;++age)  
       obs_pop[sex][year][age]=0.0;	 
}

ann_brate=vector(start_sim,fin_year+1);
m_rate=dmatrix(0,1,0,up_age);

for (year=start_sim;year<=fin_year+1;++year)
   ann_brate[year]=0.0;


get_bscountrycode_abbrev2017(country_num,&country_code,selcntry,country_abbrev,
                             &daly_factor,bs_sourcefile,bs_sourcename, bs_avefile);  /* Finds the UN 
   country_code for the given country by reading in its value from bs_sourcefile that's specified in the command line. 
   For these runs, we used bsdalcc2024.inp.  Whilst it's in this function, it also reads in the name of the files holding 
   the force of infection for the country, as well as the daly */

get_imppopdata(male_popfile,obs_pop[0],country_code,min_year_vacc,fin_year,min_age,up_age);   // Assigns the value for obs_pop for males

get_imppopdata(fem_popfile,obs_pop[1],country_code,min_year_vacc,fin_year,min_age,up_age);  // Assigns the value for obs_pop for females

printf("finished get_imppopdata\n");

get_implife_expectancy(life_expectancy_file,life_expectancy_at_birth,
                 country_code,min_year_vacc,fin_year);                         // Assigns the life expectancy
	
printf("finished get_implife_expectancy\n");


get_imp_brate_2017(brate_file,country_code,ann_brate,start_sim,fin_year+1,reqd_demog_year);  // Assigns the birth rate

for (year=start_sim;year<=fin_year+1;++year)
  printf("here year=%d ann_brate=%10.6e\t",year,ann_brate[year]);
printf("\n");

get_imp_mrate(male_mrate_file,m_rate[0],country_code,min_age,up_age,reqd_demog_year);     // Assigns the male mortality rate for reqd_demog_year
get_imp_mrate(fem_mrate_file,m_rate[1],country_code,min_age,up_age,reqd_demog_year);       // Assigns the male mortality rate for reqd_demog_year


/****************************************************************************************************/      
/* End of the section on initialise variables storing several of the demographic paramaters */
/****************************************************************************************************/      


/****************************************************************************************************/      
/* The following section loops over each of the replicates.  It first sets up names for the file containing output eventually 
submitted to VIMC (held in imperial_outfile), and the name for a file containing  summary outputs of selected aggregrated 
values which can be used for plotting and checking (held in summary_outfile).  
It also sets up a "detailed" file, but this is not used and can be ignored. The names of these files is determined by the 
scenario, replicate, bootstrap and country numbers. 
After these files have been set up, the code sends them the names of the demographic, vaccination and 
boostrap-derived force of infection input files and values for the key parameters.  These are just there for sanity checking output, 
if necessary at a later stage.
After this stage, the code calls up the reduced_readin_rubella_dynamics(), where all the model output is generated 

After the model output has been generated for each of the repetitions, the code frees up the memory that has been assigned 
to the variables

/****************************************************************************************************/      


for (replicate_num=first_rep;replicate_num<=final_rep;++replicate_num){
  reqd_bsreplicate=bs_num[replicate_num];     // holds the bootstrap number that will be used in the current model run,specified by replicate_num
  new_vacc_eff=veff[replicate_num];        // holds the vaccine efficacy that will be used in the current model run
  risk_crs=crs_risk[replicate_num];         // holds the risk of a child being born with CRS given infection in the mother in the 1st 16 weeks of pregnancy, that will be used in the current model run
  scaleFactor=sfactor[replicate_num];       // this was set to 1.0 above, so doesn't affect the code, as it's just used as a scale factor
  crs_cfr=crs_mort[replicate_num];          // holds the CRS-related mortality that will be used in the current model run


/* The following lines are just used to record the start time of the model run */
  now=time(NULL);
  strftime(s_out3,22,"%d%m%yt%Hh%Mm%Ss",localtime(&now));	
  strftime(s_out1,100,"%A_%d_%B_%Y_%H:%M:%S",localtime(&now));
  
  printf("It is now %s\n",s_out1);
  printf("s_out3=%s\n",s_out3);
  
 /*************************************************************************************************************/ 
  /* Set up output file names 
  /*************************************************************************************************************/ 
  
  sprintf(extString,"%s%d%s%d%s%d%s%d",
    ".c",country_num,"s",scen_opt,"b",reqd_bsreplicate,"r",replicate_num);  
  printf("extString=%s\n",extString);
  sprintf(detailed_outfile,"%s%s%s","output/detailed/detout",extString,"\0");
  sprintf(summary_outfile,"%s%s%s","output/summary/summ",extString,"\0");

  sprintf(imperial_outfile,"%s%s%s","output/imperial/imp",extString,"\0");

  printf("detailed_outfile=%s summary_outfile=%s imperial_outfile=%s\n",detailed_outfile,summary_outfile,imperial_outfile);

 /*************************************************************************************************************/ 
  /* End of the section setting up output file names 
  /*************************************************************************************************************/ 
	
  send_startdetails(detailed_outfile,summary_outfile,imperial_outfile,s_out1);   // Sends the start time to the output files

  send_details_to_files( detailed_outfile, summary_outfile, imperial_outfile,
                   country_num, country_code, selcntry,
					bs_sourcename, bs_avefile, scen_opt,
					reqd_bsreplicate, frac_import, 
					pvacc_again, 
					new_vacc_eff, 
					brate_file,male_mrate_file,fem_mrate_file,male_popfile,fem_popfile,
					life_expectancy_file,
					aspfert_file, 
					sia_details_file, rcv1_cov_file, rcv2_cov_file, 
					crs_cfr, scaleFactor, risk_crs );    // Sends the parameter values for the current run to the output files 


  reduced_readin_rubella_dynamics( summary_outfile, detailed_outfile, imperial_outfile,
                    country_num, country_code,selcntry,country_abbrev,			
					fin_year,
                    scen_opt,new_vacc_eff, 
					replicate_num,reqd_bsreplicate, 
					aspfert_file,
                    sia_details_file,
				    rcv1_cov_file,rcv2_cov_file,	
					bs_sourcename,bs_avefile,crs_cfr, scaleFactor, 
					risk_crs, pvacc_again,
					frac_import,
					obs_pop,
					life_expectancy_at_birth,
					m_rate,ann_brate,
					start_sim,reqd_demog_year,
					min_age,up_age,daly_factor);   // calls up the function where all the calculations for the model output are done

}


free_dvector(bs_num,0,max_rep);
free_dvector(crs_mort,0,max_rep);
free_dvector(crs_risk,0,max_rep);
free_dvector(sfactor,0,max_rep);
free_dvector(veff,0,max_rep);

free_d3tensor(obs_pop,0,1,min_year_vacc,fin_year,0,up_age);
free_dvector(life_expectancy_at_birth,min_year_vacc,fin_year);
free_vector(ann_brate,start_sim,fin_year+1);
free_dmatrix(m_rate,0,1,0,up_age);



}



void reduced_readin_rubella_dynamics(char summary_outfile[],char detailed_outfile[],
                   char imperial_outfile[],
				   int country_num,int country_code,char selcntry[],char country_abbrev[],
				   int fin_year,
                   int scen_opt,double new_vacc_eff, 
					int replicate_num, int reqd_bsreplicate,                
                   char aspfert_file[],
                  char sia_details_file[strngln],
				   char rcv1_cov_file[strngln],char rcv2_cov_file[strngln],
					char bs_sourcename[],char bs_avefile[],
					double crs_cfr, double scaleFactor, float risk_crs, 
					float pvacc_again, float frac_import,
					double ***obs_pop,double life_expectancy_at_birth[],
					double **m_rate,float *ann_brate,
					int start_sim,int reqd_demog_year,
					int min_age,int up_age,double daly_factor){

/* Function for carrying out the calculations for generating the output for VIMC */

double **sus,**incub,**infous,**immune,*mat;
double *births; 
double **effvacc_cov,**effvacc_sus,*effvacc_mat,*effvacc_9mths,*effvacc_18mths,vacc_eff;

int durn_mat_days,durn_mat_tsteps,durn_9mths,durn_9mths_tsteps;
int day_in_year,min_yrout,max_yrout;

int tsteps_pday,num_tsteps_pyr,tstep_in_year,tstep;
float tstep_size;

int days_inc_crsrisk;

int start_gavi,fin_gavi,yr_vacc,yr_for_stndisn;
int first_imp_yr,fin_imp_yr;
int low_impage_reqd,high_impage_reqd;

double preinf_period_days,infous_period_days,infous_rate_pday;
double *prop_age;
double **yr_imp_aspfert;
double **sing_pop,**sing_inf_pyr,**sing_inf_pday;
double  **sus_yrstart;
double sum_crs,sum_actual_crs;
double model_pop;
double total_popn_start;

double totlivebths_15t49;
double prop_y,prop_mat;

double actual_cov;

double **agesp_scov_9mths,**agesp_scov_mat,***agesp_scov,**rcv_cov_9mths,***rcv_cov_dose2;

double ***wgt_num_actual_crs,***wgt_store_crs_phklb_mid;
double ****asp_num_actual_crs, **asp_num_actual_infns_pday,**age_stndis_actual_infns_pday;
double foi_pday_y,foi_pday_o;

int *crs_cat,max_crs_ind; 
int v_ind,max_vind;

double **beta,**ecr;
double *lambda,rec_rate_ptstep,rec_rate_pday;
double sum_foi_y,sum_foi_o,ave_foi_y,ave_foi_o;
double popstart_y,popstart_o,popstart_mat;
double *total_vacc_actual;
int tot_days;
int yy;

int beta_num,num_betas;
double **beta_vals,**equm_annfoi,*k_val;
int low_bstrap,num_bstraps;
double *foi_ptsus_y,*foi_ptsus_o;

int age_cb,sex,cat;
int i,j,tss;

int aa,age,**age_out,age_yr,min_agefert=15,max_agefert=49;
int num_cats; 
int num_days;
int cat1, day,year,out_cat,num_outcats,yr_start_store;
int out_opt,days_since_start;

div_t count_mth;
char s[100],s_out[100];

char use_bsfile[ strngln ]; 


time_t now;

FILE *ofp,*pfp;

now = time(NULL);
strftime(s,100,"%A, %d %B %Y  %H:%M:%S",localtime(&now));
strftime(s_out,100,"%A_%d_%B_%Y_%H:%M:%S;",localtime(&now));

printf("It is now %s\n",s);


strcpy(sumfile,"crssumm.out");   // The file crssum.out is generated during the run.  The start time for the model
                                  // and values for several of the key input parameters and file names used in the current run are written to it.  
								 // However, it can be ignored or used for consistency-checking if necessary.  

ofp=fopen(sumfile,"a");
fprintf(ofp,"\nstart_time:%s;",s_out);
fclose(ofp);

yr_start_store=1995;    // First year for which output is stored 
num_outcats=13;        // number of age groups for which model output is produced 
max_crs_ind=8;         

age_cb =13;              // Age at which the force of infection changes 

tsteps_pday=4;           // Number of time steps per day

low_impage_reqd=0;        // Lowest and highest age categories required in the VIMC output file
high_impage_reqd=99; 

tstep_size=1/(tsteps_pday*1.0);           // Time step size
printf("tstep_size=%10.4f\n",tstep_size);

num_days=365;              // number of days in each year 
num_tsteps_pyr=num_days*tsteps_pday;  // number of time steps per year

days_since_start=0;

printf("Simulations start in %d\n",start_sim);

  

printf("country_num=%d country_code=%d selcntry=%s\n",country_num,country_code,selcntry);

ofp=fopen(sumfile,"a");
fprintf(ofp,"country_num:%d;country:%s;",country_num,selcntry);
fclose(ofp);


printf("yr_start_store=%d fin_year=%d up_age=%d\n",yr_start_store,fin_year,up_age);

printf("\n\nCountry_num=%d  country=%s country_cod=%d\n",country_num,selcntry,country_code);

prop_age=dvector(0,up_age);          // stores the proportion of the population that's in each singer year age stratum

for (age=0;age<=up_age;++age) prop_age[age]=0.0;

setup_propage(num_days,num_tsteps_pyr,tsteps_pday,tstep_size,start_sim,fin_year,up_age,prop_age,
                 m_rate,ann_brate);  // Calculates the proportion of the population that's in each age stratum. prop_age is used to calculate the beta values later in the code

yr_imp_aspfert=dmatrix(yr_start_store,fin_year+1,0,up_age);    // STores the age-specific fertility for each year between yr_start_store and the final year

for (year=yr_start_store;year<=fin_year+1;++year){
  for (age=0;age<=up_age;++age)
    yr_imp_aspfert[year][age]=0.0;
}
	 
get_impaspfert(aspfert_file,yr_imp_aspfert,country_code,
                    up_age,yr_start_store,fin_year+1,max_agefert);  // extracts the age-specific fertility rate and assigns it to yr_imp_aspfert[][]
		 
printf("post asp=\n");


total_popn_start= 750000;          /* population size used in model at the start of model simulations */

/*  The 3 lines below give the initial numbers of births for males and females. 
These values are then modified dynamically in subsequent years */ 
births=dvector(0,1);
births[0]=births[1] = total_popn_start*0.5/(up_age+1);
printf("births[0]=%10.6e [1]=%10.6e\n",births[0],births[1]);


get_prop_mat_and_y(&prop_mat,&prop_y,prop_age,age_cb,up_age);  /* Gets the proportion of the population at the start that's 
                                                                  made up by children with maternal immunity (prop_mat) and by children (prop_y)*/

printf("prop_mat=%10.6e prop_y=%10.6e\n",prop_mat,prop_y);


popstart_mat= total_popn_start*prop_mat; 
popstart_y=  total_popn_start*prop_y;   /* note that prop_y includes people in their first year of life, after maternal immty has waned  */
popstart_o = total_popn_start-popstart_y-popstart_mat;

printf("prop_mat=%10.6e prop_y=%10.6e \n",prop_mat,prop_y);
printf("popstart_y=%10.8e popstart_o=%10.8e prop_y=%10.6e\n",popstart_y,popstart_o,prop_y);


printf("popstart_mat=%10.6e popstart_y=%10.6e popstart_o=%10.6e\n",popstart_mat,popstart_y,popstart_o);


durn_mat_days = 182;                            // duration of maternal immunity in days
durn_mat_tsteps = durn_mat_days*tsteps_pday;     // duration of maternal immunity in number of time steps

durn_9mths = 270;
durn_9mths_tsteps = durn_9mths*tsteps_pday;

preinf_period_days= 10.0;   /* latent or pre-infectious period in days; */
infous_period_days= 11.0;  /* infectious period in days; */

infous_rate_pday=1/preinf_period_days;            /* average rate at which individuals become infectious */
rec_rate_pday=1/infous_period_days;           /* average rate at which infectious individuals recover to become immune */

/****************************************************************************************************/   
/* Define potentially useful age ranges, stored in age_out[][] and crs_cat[] 
/* These are defined in the function new_define_outcats()
/****************************************************************************************************/   

age_out=imatrix(1,num_outcats,0,1);     /* age_out[][] is used to define the age ranges which might be of interest;
                                           age_out[i][0] = lower limit of the age range for group i; 
                                           age_out[i][1] = upper limit of the age range for group i */
										   
for (i=1;i<=num_outcats;++i) 
  age_out[i][0]=age_out[i][1]=0;	

crs_cat=ivector(1,max_crs_ind);     /* crs_cat[] stores indexes of age_out which are relevant for CRS. e.g. crs_cat[1]=4, 
                                       since age_out[4][*] covers the age range 15-14 years, which is the earliest age range for 
									   which fertility rates are provided*/

for (i=1;i<=max_crs_ind;++i) crs_cat[i]=0;

new_define_outcats(age_out,num_outcats,crs_cat,max_crs_ind);    /* this function defines the values for age_out[*][*] and crs_cat[] */

/****************************************************************************************************/   
/* End of section defining potentially useful age ranges
/****************************************************************************************************/   



out_opt=1;

vacc_eff = new_vacc_eff;     

printf("vacc_eff=%10.6e\n",vacc_eff);
printf("Last year for which output on the incidence of rubella and CRS are provided: %d\n",fin_year);

/* the following determine the years for which output is provided */

min_yrout=2000; max_yrout=fin_year;     


ofp=fopen(sumfile,"a");
fprintf(ofp,"tsteps_pday=%d;durn_mat_days=%d;preinf_period_days=%2.1f;infous_period_days=%2.1f;risk_crs=%3.2f;vacc_eff=%3.2f;yr_start_sim=%d;",
                        tsteps_pday,durn_mat_days,preinf_period_days,infous_period_days, risk_crs,vacc_eff,start_sim);
fclose(ofp);




low_bstrap=1; num_bstraps=1; /* This reflects the number of bstraps over which the 
                                following code could loop.  It's currently set to 1 (so there's no looping), 
								as the looping over the bootstraps is 
								controlled outside this section of code. Several variables are 
								indexed by the bstrap number below and they are used in functions in other 
								files, so the indexing is left in for now. */

num_betas=num_bstraps;

/****************************************************************************************************/ 
/* Set up and define the equilibrium (pre-vaccination) force of infection and beta values (beta[1] and beta[2]) - 
   see below. 
   The file holding the equilibrium force of infection depends on whether the point estimate (average) value is
   used (in which case reqd_bsreplicate=0) or a bootstrap-derived vaule is used (reqd_bsreplicate>0)
/****************************************************************************************************/ 


foi_ptsus_y=dvector(low_bstrap,num_bstraps);         // force of infection in the young   
foi_ptsus_o=dvector(low_bstrap,num_bstraps);         // force of infection in the "old"

beta_vals=dmatrix(low_bstrap,num_bstraps,1,2);       // beta values
equm_annfoi=dmatrix(low_bstrap,num_bstraps,1,2);     // equilibrium annual force of infection

ofp=fopen(sumfile,"a");
fprintf(ofp,"num_bstraps=%d;",num_bstraps);
fclose(ofp);


  printf("here now\n");
  k_val=dvector(1,num_bstraps);                      // factor by which beta_yo and beta_oy differs from beta_oo. It's calculated in the 
                                                     // function get_bstraps_and_betas_sing_2015() using the equilibrium force of infection
   
  for (i=1;i<=num_bstraps;++i) k_val[i]=0.0; 
 
  if( reqd_bsreplicate > 0 ){
	strcpy( use_bsfile, bs_sourcename );
  }
  else{
	strcpy( use_bsfile, bs_avefile );
  }  
  get_bstraps_and_betas_sing_2015(age_cb,up_age,foi_ptsus_y,foi_ptsus_o,equm_annfoi,beta_vals,prop_age,
	infous_period_days,total_popn_start,k_val,reqd_bsreplicate, use_bsfile, sumfile);  // This function calculates the values for beta[1], beta[2] and k_val values from the equilibrium 
	                                                                                   // force of infection that's read in from use_bsfile, and the proportion of 
																					   // the age distribution of the population, stored in prop_age.
																					   // beta[1] is the child-child contact parameter; beta[2] is the adult-adult contact parameter 
  	
  	 printf("k_vals: [1]=%10.6e\n",k_val[1]);
						   
free_dvector(prop_age,0,up_age);


/****************************************************************************************************/ 
/* End of the section for setting up and defining the equilibrium (pre-vaccination) force of infection and beta values
/****************************************************************************************************/ 


/****************************************************************************************************/ 
/* This section sets up the variables storing the coverage in SIAs and routine vaccinations and then reads in the 
values provided by VIMC
/****************************************************************************************************/ 


agesp_scov_9mths = dmatrix( min_year_vacc, max_year_vacc+2, 0, 1);       // SIA coverage for 9 month olds for each year
agesp_scov_mat   = dmatrix( min_year_vacc, max_year_vacc+2, 0, 1);       // SIA coverage at age 6 months for each year
agesp_scov       = d3tensor( min_year_vacc, max_year_vacc+2, 0, 1, 0, up_age);   // SIA coverage for people aged between 12 months and up_age for each year


rcv_cov_9mths=dmatrix(min_year_vacc,max_year_vacc+2,0,1);     // RCV coverage for 9 month olds for each year
printf("initialized rcv_cov etc\n");

rcv_cov_dose2=d3tensor(min_year_vacc,max_year_vacc+2,0,1,0, up_age);   // RCV coverage for dose 2 for people aged between 12 months and up_age for each year
printf("initialized rcv_cov etc\n");


for ( year=min_year_vacc; year <= max_year_vacc+2; ++year ){
    for( sex=0; sex<=1; sex++){
         agesp_scov_9mths[year][sex] = agesp_scov_mat[year][sex] = 0.0;
         for (age=0; age<=up_age; ++age) agesp_scov[year][sex][age] = 0.0;
   }
}

for ( year=min_year_vacc; year <= max_year_vacc+2; ++year ){
	for (sex=0;sex<=1;++sex){
         rcv_cov_9mths[year][sex] = 0.0;
         for (age=0; age<=up_age; ++age) rcv_cov_dose2[year][sex][age] = 0.0;
	}
}

printf("initialized agesp_cov etc\n");
			
fin_gavi=2101; 

start_gavi=1980;  

yr_for_stndisn = 2000;    // For consistency checking, the model calculates some variables which are standardised to yr_for_standisn.  This output is not provided for VIMC.

first_imp_yr=2000;        // First year of output required for VIMC
fin_imp_yr=2100;          // Last year year of output required for VIMC

imp_assign_include_sia_and_vaccn( sumfile, sia_details_file, rcv1_cov_file, rcv2_cov_file, 
				country_num,country_code, agesp_scov_mat, agesp_scov_9mths, agesp_scov,
				rcv_cov_9mths, rcv_cov_dose2, min_year_vacc, max_year_vacc, fin_gavi, 0, up_age,
				scaleFactor );               // This function reads in the age-specific vaccination coverage provided by VIMC 
				
printf("completed assign_include_sia_and_vaccn\n");

/****************************************************************************************************/ 
/* End of the section setting up the variables storing the coverage in SIAs and routine vaccinations and reading in the 
values provided by VIMC
/****************************************************************************************************/ 


/****************************************************************************************************/ 
/* This section sets up and initialises the contact parameters, compartments and various output variables
/****************************************************************************************************/ 



beta=dmatrix(0,1,0,1);            //beta
ecr=dmatrix(0,1,0,1);            // effective contact rate

effvacc_cov=dmatrix(0,1,0,up_age);   // effective coverage among those aged between 12 months and up_age
effvacc_sus=dmatrix(0,1,0,up_age);   // effective coverage among susceptibles those aged between 12 months and up_age,
                                     // calculated taking account of correlation between vaccine doses
effvacc_mat=dvector(0,1);        // effective coverage among those aged 6 months
effvacc_9mths=dvector(0,1);      // effective coverage among those aged 9 months
effvacc_18mths=dvector(0,1);      // effective coverage among those aged 18 months [not used in practice]

for (sex=0;sex<=1;++sex){
effvacc_mat[sex]=effvacc_9mths[sex]=effvacc_18mths[sex]=0.0;
for (age=0;age<=up_age;++age) 
  effvacc_cov[sex][age]=effvacc_sus[sex][age]=0.0;
}

fprintf(stderr,"initialized effvacc_cov\n");

sus_yrstart=dmatrix(0,1,0,up_age); 

lambda=dvector(0,up_age);
mat=dvector(0,1);                    // number of males (index=0) and females (index=1) aged <6 months. 
sus=dmatrix(0,1,0,up_age);           // number of susceptible males (index=0) and females (index=1) aged 12 months - up_age
incub=dmatrix(0,1,0,up_age);         // number of pre-infectious males (index=0) and females (index=1) aged 12 months - up_age
infous=dmatrix(0,1,0,up_age);       // number of infectious males (index=0) and females (index=1) aged 12 months - up_age
immune=dmatrix(0,1,0,up_age);       // number of immune males (index=0) and females (index=1) aged 12 months - up_age
sing_pop=dmatrix(0,1,0,up_age);     // number of males (index=0) and females (index=1) aged 12 months - up_age
sing_inf_pyr=dmatrix(0,1,0,up_age);   // number of infections in the current year among males (index=0) and females (index=1) aged 12 months - up_age
sing_inf_pday=dmatrix(0,1,0,up_age);   // number of infections in the current day among males (index=0) and females (index=1) aged 12 months - up_age

fprintf(stderr,"initialized sing_inf_pday\n");

tot_days=num_days*(fin_year-yr_start_store+1);    // Total number of days for which output of interest is stored
printf("tot_days=%d\n",tot_days);


days_inc_crsrisk=112;       // number of days during pregnancy during which infection carries an increased risk of a child being born with CRS

max_vind=0;             // Several of the outputs of interest are indexed between 0 and max_vind, and between 1 and num_betas, 
                         // providing the option of generating output for further strata if needed.
                        // As max_vind is 0, and num_betas=1, this option is currently not used
if (out_opt==1){

   printf("am here\n");

  wgt_num_actual_crs=d3tensor(1,num_betas,0,max_vind,0,tot_days);    // Total number of CRS cases born on each day between 0 and tot_days, standardized to the observed population 
                                                                     // for the given year 
  
  asp_num_actual_crs=d4tensor(1,num_betas,0,max_vind,0,up_age,0,tot_days);  // Total number of CRS cases born to people aged 0-up_age on each day between 
                                                                            // 0 and tot_days, standardized to the observed population 
                                                                     // for the given year
  asp_num_actual_infns_pday= dmatrix(0,up_age,0,tot_days );    // Total number of infections among people aged 0-up_age on each day between 
                                                              // 0 and tot_days, standardized to the observed population 
                                                              // for the given year
  
  
  age_stndis_actual_infns_pday= dmatrix(0,up_age,0,tot_days );  // Total number of infections among people aged 0-up_age on each day between 
                                                              // 0 and tot_days, standardized to the observed population 
                                                              // in the yr_for_stndisn.   
															  
  wgt_store_crs_phklb_mid=d3tensor(1,num_betas,0,max_vind,0,tot_days);  // Number of CRS cases per 100,000 live births, weighted by the age-specific 
                                                                // fertility rate

  printf("initialised here\n");
  
  for (beta_num=1;beta_num<=num_betas;++beta_num){
  	for (day=0;day<=tot_days;++day){
        for (age=0;age<=up_age;++age) asp_num_actual_infns_pday[age][day]=age_stndis_actual_infns_pday[age][day]=0.0 ;
       for (v_ind=0;v_ind<=max_vind;++v_ind){
		 wgt_store_crs_phklb_mid[beta_num][v_ind][day]=0.0;
		 for (age=0;age<=up_age;++age){
		   asp_num_actual_crs[beta_num][v_ind][age][day]=0.0;
		 }
       }	     
    }	
  }				    
   printf("now here\n");
}

total_vacc_actual=dvector(min_year_vacc,fin_year);             // Total number of vaccinees. They're not used in the dynamics but can be used to 
                                                               // for consistency checking
															   
for (year=min_year_vacc;year<=fin_year;++year) total_vacc_actual[year]=0.0;


/****************************************************************************************************/ 
/* End of the section which sets up and initialises the contact parameters, compartments and various output variables
/****************************************************************************************************/ 



for (v_ind=0;v_ind<=0 ;++v_ind){   
  
for (beta_num=1;beta_num<= 1 ;++beta_num){            /* This provides the option of looping over all 
                                                         the combinations of beta values if there were to be more than one set of beta vaules.  
														 The looping is specified else and so this loop is just done for one set of beta values here  */

/****************************************************************************************************/   
/* Calculate the contact parameters which are used to calculate the force of infection in each time step */
/****************************************************************************************************/   

   fprintf(stderr,"beta_num=%d\n",beta_num);
   fprintf(stderr,"Program running...starting v_ind=%d \n",v_ind);

   printf("beta_num=%d\n",beta_num);
   printf("Program running...starting v_ind=%d \n",v_ind);
   
   fprintf(stderr,"beta_num=%d\n",beta_num);
   fprintf(stderr,"Program running...starting v_ind=%d \n",v_ind);
   beta[0][0]=beta_vals[beta_num][1]; 
   beta[1][1]=beta_vals[beta_num][2]; 

  beta[0][1]=beta[1][0]=k_val[beta_num]*beta[1][1];

   ecr[0][0]=beta[0][0]*popstart_y;
   ecr[0][1]=beta[0][1]*popstart_y;
   ecr[1][0]=beta[1][0]*popstart_o;
   ecr[1][1]=beta[1][1]*popstart_o;

   printf("beta in units of per day\n");
   for (i=0;i<=1;++i)
     for (j=0;j<=1;++j)
       printf("beta[%d][%d]=%10.6e per day\n",i,j,beta[i][j]); 

/****************************************************************************************************/   
/* End of section which calculates the contact parameters */
/****************************************************************************************************/   


  new_initialize_popn(up_age,age_cb,equm_annfoi[beta_num],preinf_period_days,infous_period_days,
                        num_days,births,mat,sus,incub,infous,immune,sing_pop);  // This initialises the compartments
				
tss=0;   // Time since the start


/****************************************************************************************************/   
/* The following is the main loop over which the output is generated.  There's an initial for loop which 
   loops over each day and this has a further subloop to loop over the time steps per day.
   The outputs of interest for VIMC (e.g. number of CRS cases by age of the mother, number of infections are stored
   for each time step.  After reaching the end of the final year of the simulations, the output per time step is sent to 
   the function send_CRS_incidence, where it is aggregated to provide the yearly output required by VIMC
   
/****************************************************************************************************/   

for (year=start_sim;year<=fin_year;++year){  
  fprintf(stderr,"year=%d\n",year);
  get_applied_effcov(year,min_year_vacc,effvacc_mat,effvacc_9mths,effvacc_cov,
                      agesp_scov_mat,agesp_scov_9mths,agesp_scov,rcv_cov_9mths,
					  rcv_cov_dose2,vacc_eff,up_age);            // This calculates the age-specific effective coverage
  get_applied_suscov(year,min_year_vacc,effvacc_sus,
					  agesp_scov,rcv_cov_9mths,
					  rcv_cov_dose2,vacc_eff,up_age,pvacc_again);  // This calculates the age-specific coverage among susceptibles, accounting for 
					                                               // correlations between vaccine doses

   if (year>=min_year_vacc){    // This calculates the total number of vaccinees, which is stored in tota_vacc_actual.  It's not used in the 
                                 // transmission dynamics themselves.  , but can be 
                                // used for cross-checks
   	 for (sex=0;sex<=1;++sex) total_vacc_actual[year]+=obs_pop[sex][year][0]*(effvacc_mat[sex]+effvacc_9mths[sex])/vacc_eff;				 
	 				 
	 for (age=1;age<=up_age;++age){
		for (sex=0;sex<=1;++sex) total_vacc_actual[year+1]+=obs_pop[sex][year][age-1]*effvacc_cov[sex][age-1]/vacc_eff;		
		
	 }
   }

  sum_foi_y=0.0;                   // This is used to calculate the cumulative foi in each year. It's not used 
  sum_foi_o=0.0;                   // in any of the calculations and is just used for monitoring

  for (sex=0;sex<=1;++sex)
     for (age=0;age<=up_age;++age)
        sing_inf_pyr[sex][age]=0.0;

  tstep_in_year=0;

  for (day=0;day<=num_days-1;++day){    // 
    day_in_year=day; 

	count_mth=div(day_in_year,30);
	if (count_mth.rem==0)	{	
	  for (sex=0;sex<1;++sex)
	    introduce_importations(up_age,sus[sex],infous[sex], frac_import);    /* this reseeds the infectious popn and adjusts the no of susceptible 
                                                       individuals at the start of each year. frac_import is specified in the command line and was set 
													   to zero for VIMC runs*/
	}
	
  for (sex=0;sex<=1;++sex)
     for (age=0;age<=up_age;++age)
        sing_inf_pday[sex][age]=0.0;

    for (tstep=0;tstep<tsteps_pday;++tstep){  /* matching } after } of for (day... */

	  growing_calc_foi(age_cb,lambda,ecr,infous,sing_pop,mat,up_age);  /* this calculates the force of infection in the current time step */

      sum_foi_y+=lambda[10];                // Sum_foi_y and sum_foi_o are the cumulative foi since they were initialised. They're 
      sum_foi_o+=lambda[20];	            // not used in the model equations but can be used for keeping track of the force of infection

      for (sex=0;sex<=1;++sex){
        if (tstep_in_year<(num_tsteps_pyr-1)){      // the following updates compartments in each time step except for that at the end of the year

          for (age=up_age;age>0;--age)		  		  
    		update_compartments(sex,age,year,day,tstep_in_year,durn_mat_tsteps,sus,incub,infous,immune,lambda,
			           sing_inf_pyr,sing_inf_pday,m_rate,tstep_size,infous_rate_pday,rec_rate_pday,effvacc_18mths);	// this updates the size of each of 
					                                                                                     // the compartments for those aged over 12 months
			
            update_fyol_compartments(sex,year,day,tstep_in_year,durn_mat_tsteps,durn_9mths_tsteps,
                        mat,sus,incub,infous,immune,lambda,sing_inf_pyr,sing_inf_pday,
                        m_rate,tstep_size,infous_rate_pday,rec_rate_pday,effvacc_mat,effvacc_9mths);  // this updates the size of each of 
					                                                                                     // the compartments for those aged under 12 months
				  
        }  /* matches if (tstep_in_year< loop */

    }  /* matches for (sex= loop */

    if (tstep_in_year==(num_tsteps_pyr-1)){    // the following updates the compartments at the end of the year, when vaccination and new births occur
       nounvacc_vacc_store_brate_new_end_of_year(sus,incub,infous,immune,lambda,
		                                          effvacc_sus,mat,effvacc_mat,sing_inf_pday,sing_inf_pyr,m_rate,
                                                  up_age,infous_rate_pday,rec_rate_pday,tstep_size,year,ann_brate[year+1],sing_pop);
    }

    ave_foi_y=sum_foi_y*tstep_size/(1.0*num_tsteps_pyr);              // this calculates the average force of infection during the year. It's not 
    ave_foi_o=sum_foi_o*tstep_size/(1.0*num_tsteps_pyr);              // used in the calculations and is just used for monitoring purposes

    /// This section calculates the model population size (model_pop) and the model population size by sex in each single year age band (sing_pop[][])
    model_pop=0.0;
    for (sex=0;sex<=1;++sex){
      for (age=1;age<=up_age;++age) {
        sing_pop[sex][age]=sus[sex][age]+incub[sex][age]+infous[sex][age]+immune[sex][age];
        model_pop+=sing_pop[sex][age];
      }
      sing_pop[sex][0]=mat[sex]+sus[sex][0]+incub[sex][0]+infous[sex][0]+immune[sex][0];
      model_pop+=sing_pop[sex][0];
    }
	
	
  ++tstep_in_year;
 
  }  /* matches for tstep loop */
    sum_crs=0.0;
     sum_actual_crs=0.0;
	
	for (age=0;age<=up_age;++age){ 
           if (year>=yr_start_store) {
               asp_num_actual_infns_pday[age][tss]=(sing_inf_pday[0][age]*obs_pop[0][year][age]/sing_pop[0][age])+(sing_inf_pday[1][age]*obs_pop[1][year][age]/sing_pop[1][age]); 
			                                      // age-specific number of infections in each age band in the current time step, scaled according to 
												  // the population provided by VIMC
			   
			   age_stndis_actual_infns_pday[age][tss]= (sing_inf_pday[0][age]*obs_pop[0][yr_for_stndisn][age]/sing_pop[0][age] +
			                                             sing_inf_pday[1][age]*obs_pop[1][yr_for_stndisn][age]/sing_pop[1][age]);
			                                      // age-specific number of infections in each age band in the current time step, standardised to the population in yr_for_stndisn.
          										// 	 This isn't provided for VIMC but is used for internal consistancy checking
														 														 
			   
		      if ((age>=min_agefert) && (age<=max_agefert) ){
			     sum_actual_crs+=(sus[1][age]/sing_pop[1][age])*yr_imp_aspfert[year][age]*obs_pop[1][year][age]*(1-exp(-lambda[20]*days_inc_crsrisk))*risk_crs/365.0; 
				                                 // Total number of CRS cases, scaled according to 
												  // the population provided by VIMC.
                                                  // This isn't provided for VIMC but is used for internal consistancy checking
				 
				 asp_num_actual_crs[beta_num][v_ind][age][tss]=
				       (sus[1][age]/sing_pop[1][age])*yr_imp_aspfert[year][age]*obs_pop[1][year][age]*(1-exp(-lambda[20]*days_inc_crsrisk))*risk_crs/365.0; 
					                             // Number of CRS cases born to mothers in the current age band in the current time step, scaled according to 
												  // the population provided by VIMC.
				   					   
                 if (out_opt==1) 
					sum_crs+=sus[1][age]*yr_imp_aspfert[year][age]*(1-exp(-lambda[20]*days_inc_crsrisk))*risk_crs/365; 				     
                                                 //Total number of CRS cases in the model population. This is used to calculate the number
												 // of CRS cases per 100,000 live births below
			  }
           }
     }  // matches for (age= loop 	  
	 
     if ((year>=yr_start_store)&& (out_opt==1)) {
        totlivebths_15t49=0.0;
		for (age=min_agefert;age<=max_agefert;++age)
		   totlivebths_15t49+=sing_pop[1][age]*yr_imp_aspfert[year][age]/365.0;				// Total number of live births

   		wgt_store_crs_phklb_mid[beta_num][v_ind][tss]=sum_crs*100000/totlivebths_15t49;   // Number of CRS number
												 // of CRS cases per 100,000 live births, weighted by the age-specific fertility. This isn't provided for VIMC
												 // but used for internal consistency checking and plotting
		   
        wgt_num_actual_crs[beta_num][v_ind][tss]=sum_actual_crs;  // Total number of CRS cases born in the current time step.  This isn't provided for VIMC
												 // but used for internal consistency checking and plotting

     }

   ++days_since_start;
   if (year>=yr_start_store) ++tss;

  }  /* matches for day loop */
}  /* matches for year loop */

} 

printf("finished beta loop\n");


}   /* matches for v_ind loop */

/************************************************************************************************/
/* End of the loop in which the rubella dynamics are simulated
   The function below (send_CRS_incidence) sends the outputs of interest calculated to the output file 
   for VIMC and to the detailed and summary output files.  The summary output file has aggregated
   output which can be used for plotting and checking that the output makes sense
 /************************************************************************************************/  

send_CRS_incidence(detailed_outfile,summary_outfile,imperial_outfile,
                   reqd_bsreplicate,replicate_num,
				   365,yr_start_store,country_num, selcntry,country_abbrev,
				   tot_days,
                   total_vacc_actual,
				   asp_num_actual_crs,
				   wgt_num_actual_crs,wgt_store_crs_phklb_mid,
                   asp_num_actual_infns_pday,
				   age_stndis_actual_infns_pday,
				   start_gavi,fin_gavi,fin_year,
				   first_imp_yr,fin_imp_yr,
				   crs_cfr,daly_factor,
				   life_expectancy_at_birth,
                   up_age, obs_pop,
                   low_impage_reqd,high_impage_reqd);  
		
/* In the rest of this function, the memory allocated for various variables is freed */ 

free_dmatrix(yr_imp_aspfert,yr_start_store,fin_year+1,0,up_age);

free_d3tensor(wgt_num_actual_crs,1,num_betas,0,max_vind,0,tot_days);

printf("freed wgt_num_actual_crs\n");

free_d4tensor(  asp_num_actual_crs,1,num_betas,0,max_vind,0,up_age,0,tot_days);

printf("freed asp_num_actual_crs\n");

  free_dmatrix(asp_num_actual_infns_pday,0,up_age,0,tot_days );
  
printf("freed asp_num_actual_infns_pday\n");  
  
  free_dmatrix(age_stndis_actual_infns_pday,0,up_age,0,tot_days );  

printf("freed age_stndis_actual_infns_pday\n");  

free_d3tensor(wgt_store_crs_phklb_mid,1,num_betas,0,max_vind,0,tot_days);

printf("freed wgt_store_crs_phklb_mid\n");  

free_dvector(births,0,1);

printf("freed births\n");

free_dvector(foi_ptsus_y,low_bstrap,num_bstraps);
free_dvector(foi_ptsus_o,low_bstrap,num_bstraps);

printf("foi_ptsus_o\n");

free_dmatrix(beta_vals,1,num_betas,1,2);
free_dmatrix(equm_annfoi,1,num_betas,1,2);

printf("equm_annfoi\n");

  free_dvector(k_val,1,num_bstraps);

free_dmatrix( agesp_scov_9mths, min_year_vacc, max_year_vacc+2, 0, 1);
free_dmatrix( agesp_scov_mat , min_year_vacc, max_year_vacc+2, 0, 1);
free_d3tensor(agesp_scov, min_year_vacc, max_year_vacc+2, 0, 1, 0, up_age);

printf("freed agesp_scov\n");

free_dmatrix(rcv_cov_9mths,min_year_vacc,max_year_vacc+2,0,1);

free_d3tensor(rcv_cov_dose2,min_year_vacc,max_year_vacc+2,0,1,0, up_age);

printf("freed rcv_cov_dose2\n");

free_dvector(mat,0,1);
free_dmatrix(beta,0,1,0,1);
free_dmatrix(ecr,0,1,0,1);

printf("freed ecr\n");

free_dmatrix(sus,0,1,0,up_age);
free_dmatrix(incub,0,1,0,up_age);
free_dmatrix(infous,0,1,0,up_age);
free_dmatrix(immune,0,1,0,up_age);
free_dvector(lambda,0,up_age);
free_dmatrix(sing_pop,0,1,0,up_age);

printf("freed sing_pop\n");

free_dmatrix(effvacc_cov,0,1,0,up_age);
free_dvector(effvacc_mat,0,1);
free_dvector(effvacc_18mths,0,1);

printf("freed effvacc_18mths\n");

free_imatrix(age_out,1,num_outcats,0,1);

printf("freed age_out\n");

free_ivector(crs_cat,1,max_crs_ind);

printf("freed crs_cat\n");

free_dmatrix(sing_inf_pyr,0,1,1,num_outcats);

printf("freed sing_inf_pyr\n");
free_dmatrix(sing_inf_pday,0,1,1,num_outcats);

printf("sing_inf_pday\n");

now = time(NULL);
strftime(s,100,"%A, %d %B %Y  %H:%M:%S",localtime(&now));
printf("It is now %s\n",s);

}


void new_define_outcats(int **age_out,int num_outcats,int crs_cat[],int max_crs_ind){
 /* This function defines the values for age_out[*][*], which are the age groups for which model
    output is provided  */

int cat1;
int index,ind,min_crs_cat,cat_15t44;

  age_out[1][0]=0;age_out[1][1]=4;
  age_out[2][0]=5;age_out[2][1]=9;
  age_out[3][0]=10;age_out[3][1]=14;
  age_out[4][0]=15;age_out[4][1]=19;
  age_out[5][0]=20;age_out[5][1]=24;
  age_out[6][0]=25;age_out[6][1]=29;
  age_out[7][0]=30;age_out[7][1]=34;
  age_out[8][0]=35;age_out[8][1]=39;
  age_out[9][0]=40;age_out[9][1]=44;
  age_out[10][0]=45;age_out[10][1]=49;
  age_out[11][0]=50;age_out[11][1]=74;

  age_out[12][0]=0;age_out[12][1]=74;
  age_out[13][0]=15;age_out[13][1]=44;

  min_crs_cat=4;
  cat_15t44=13;

  index=min_crs_cat;
  for (ind=1;ind<max_crs_ind;++ind){
    crs_cat[ind]=index;
    ++index;
  }
  crs_cat[max_crs_ind]=cat_15t44;

  for (ind=1;ind<=max_crs_ind;++ind) printf("ind=%d crs_cat=%d\n",ind,crs_cat[ind]);


printf("Output is provided in the following age groups:\n");
for (cat1=1;cat1<=num_outcats;++cat1)
  printf("cat1=%d out_cat[0]=%2d [1]=%2d\n",cat1,age_out[cat1][0],age_out[cat1][1]);

}

